const { json } = require("express");

(function(){
    class User {
        constructor(username, password,game_w,game_c,game_h) {
                this._username = username;
                this._password = password;
                this._game_w  = game_w;
                this._game_c  = game_c;
                this._game_h  = game_h;
            }
    
        get username() { return this._username }
        get password() { return this._password }
        get game_w_score() {return this._game_w}
        get game_c_score() {return this._game_c}
        get game_h_score() {return this._game_h}
    
        toJSON() {
            let jsn = new Object();
            jsn.username = this._username;
            jsn.password = this._password;
            jsn.game_w = this.game_w;
            jsn.game_c = this.game_c;
            jsn.game_h = this.game_h;
            
            return jsn;
        }

        static fromJSON(jsn) {
            //check not null
            if (jsn == null) { return "null value" } //{throw new Error("null value")}
            //validate username is string
            let isValidUsername = jsn.hasOwnProperty("username") && typeof jsn.username == "string" && jsn.username.length > 2 && jsn.username.length < 21
            if (!isValidUsername) { return "invalid username" } //{throw new Error("invalid username")}
            //validate password is string
            let isValidPassword = jsn.hasOwnProperty("password") && typeof jsn.password == "string" && jsn.password.length > 7 && jsn.password.length < 100
            if (!isValidPassword) { return "invalid password" } //{throw new Error("invalid password")}
    
            if (isValidUsername && isValidPassword) {
                let u = new User(
                    jsn.username,
                    jsn.password,
                    jsn.game_w,
                    jsn.game_c,
                    jsn.game_h);
                
                return u;
            }
        }
    }



    var moduleExports = {
        User: User
        
    }
    if (typeof __dirname == 'undefined')
    window.exports = moduleExports;
    else
    module.exports = moduleExports

}());
