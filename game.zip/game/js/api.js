const dao = require('./dao.js');
const User = require('../shared/model.js').User;

//cookies to stote session data and session
const cookieParser = require("cookie-parser");
const session = require('express-session');

//everything needed for the express app is contained within this module
const express = require('express');
const bcrypt = require('bcrypt');

const app = express();
const API_PORT = 32741;
app.use(express.json())
app.use(express.urlencoded({ extended: true })) //optional but useful for url encoded data

// creating 24 hours from milliseconds
const oneDay = 1000 * 60 * 60 * 24;
//session  and cookie middleware
app.use(session({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false
}))
app.use(cookieParser());

//set up & export a function to run the app
function run() {
    // intitialise the database 
    dao.init()
        //only start listening once the database initialisation has finished successfully
        .then(() => app.listen(API_PORT, () => console.log(`Listening on localhost: ${API_PORT}`)))
        .catch(err => console.log(`Could not start server`, err))
}

module.exports = { run: run };





const getUserRoute = function(req,res){
    dao.getUsers()
        .then(users =>{
            res.json(users)
        })
        .catch(err => {
            res.status(400).json({status: "error", msg: "could not find users" })
            console.log("Could not find users",err);
        })
}

//get all the information about  that user
const getByUsernameRoute = function(req, res) {
    let username = req.params.username
    dao.getByUsername(username)
        .then(user => {
            res.json(user)
        })
        .catch(err => {
            res.status(400).json({ status: "error", msg: "could not find users" });
            console.log("Could not find user", err);
        })
}

const addUserRoute = function(req, res) {
    let username = req.body.username
    let password = req.body.password

    //check if username alreay exists
    password = bcrypt.hashSync(password, 10);
    let user = {username: username, password: password, game_w:0, game_c:0, game_h:0}; //default game pass:0

    dao.getByUsername(username)
        .then(userResponse => {
            if (userResponse != "null value") {
                console.log("api user exists", user)
                res.status(400).json({ msg: "Username already exists" })
            } else {
                console.log("api catch username doesn't exist")
                console.log(user);
                    //add user to DB as username doesnt exist
                dao.addUser(user)
                    .then(id => res.json({ msg: "User added", id: id }))
                    .catch(err => {
                        let msg = "Could not add user"
                        res.status(400).json({ msg: msg, err: "Error" });
                        console.log(msg, err);
                    })
            }
        })
        .catch(err => {
            let msg = "Error getting user by username"
            res.status(400).json({ msg: msg, err: "Error" });
            console.log(msg, err);
        })
}

const hashingpassword = function(req, res){
    let username = req.params.username
    let password = req.body.password


    dao.getByUsername(username)
        .then(user =>{
            if (bcrypt.compareSync(password, user.password)) {
                //get the record of the user and store in the session
                console.log("login",user)
                req.session.user = new Object();
                req.session.user.name = username;
                req.session.user.game_c = user._game_c;
                req.session.user.game_w = user._game_w;
                req.session.user.game_h = user._game_h;               
                console.log("login success", req.session);
                res.json({ msg: "successful" })
            } else {
                req.session.destroy();
                res.json({ msg: "it is not matched" })
            }
        })
        .catch(err =>{
            req.session.destroy();
            res.status(400).json({status:"error", msg: "could not find users"});
            console.log("Could not find the user", err);
        })
}

//old method of update

// const updateGame_c = function(req, res) {
//     let username = req.body.username
//     let newScore = req.body.score

//     dao.getByUsername(username)
//         .then(userResponse => {
//             if (userResponse != "null value") {
//                 let old_score = userResponse._game_c;
//                 console.log(userResponse);
//                 console.log("api user exists, so update", username, old_score)
//                 // res.status(400).json({ msg: "Find the username, ready to update" })
//                 if (newScore > old_score) {
//                     req.session.user.game_c = newScore;
//                     dao.updateGame_c(username, newScore)
//                         .then(modifiedNumber => res.json({msg:"Updated record", number:modifiedNumber}))
//                         .then(req.session.user.game_c = newScore)
//                         .catch(error => {
//                             let msg = "Error when trying to update record"
//                             res.status(400).json({ msg: msg, err: "Error" });
//                             console.log(msg, err);
//                         })
                    
//                 } else {
//                     console.log("No better record")
//                     res.json({msg:"No better record"})
//                 }
//             } else {
//                 console.log("api catch username doesn't exist")
    
//             }
//         })
//         .catch(err => {
//             let msg = "Error updating user by username//eariler call"
//             res.status(400).json({ msg: msg, err: "Error" });
//             console.log(msg, err);
//         })
// }

const updateGame_c = function(req, res) {
    let username = req.body.username
    let newScore = req.body.score * 2

    dao.getByUsername(username)
        .then(userResponse => {
            if (userResponse != "null value") {
                let old_score = userResponse._game_c;
                console.log(userResponse);
                console.log("api user exists, so update", username, old_score)
                newScore = newScore + old_score;
                dao.updateGame_c(username, newScore)
                    .then(modifiedNumber => res.json({msg:"Updated record", number:modifiedNumber}))
                    .then(req.session.user.game_c = newScore)
                    .catch(error => {
                        let msg = "Error when trying to update record"
                        res.status(400).json({ msg: msg, err: "Error" });
                        console.log(msg, err);
                    })


            } else {
                console.log("api catch username doesn't exist")
    
            }
        })
        .catch(err => {
            let msg = "Error updating user by username//eariler call"
            res.status(400).json({ msg: msg, err: "Error" });
            console.log(msg, err);
        })
}


const updateGame_w = function(req, res) {
    let username = req.body.username
    let newScore = req.body.score * 2

    dao.getByUsername(username)
        .then(userResponse => {
            if (userResponse != "null value") {
                let old_score = userResponse._game_w;
                console.log(userResponse);
                console.log("api user exists, so update", username, old_score)
                newScore = newScore + old_score;
                dao.updateGame_w(username, newScore)
                    .then(modifiedNumber => res.json({msg:"Updated record", number:modifiedNumber}))
                    .then(req.session.user.game_w = newScore)
                    .catch(error => {
                        let msg = "Error when trying to update record"
                        res.status(400).json({ msg: msg, err: "Error" });
                        console.log(msg, err);
                    })


            } else {
                console.log("api catch username doesn't exist")
    
            }
        })
        .catch(err => {
            let msg = "Error updating user by username//eariler call"
            res.status(400).json({ msg: msg, err: "Error" });
            console.log(msg, err);
        })
}

const updateGame_h = function(req, res) {
    let username = req.body.username
    let newScore = req.body.score * 2

    dao.getByUsername(username)
        .then(userResponse => {
            if (userResponse != "null value") {
                let old_score = userResponse._game_h;
                console.log(userResponse);
                console.log("api user exists, so update", username, old_score)
                newScore = newScore + old_score;
                dao.updateGame_h(username, newScore)
                    .then(modifiedNumber => res.json({msg:"Updated record", number:modifiedNumber}))
                    .then(req.session.user.game_h = newScore)
                    .catch(error => {
                        let msg = "Error when trying to update record"
                        res.status(400).json({ msg: msg, err: "Error" });
                        console.log(msg, err);
                    })


            } else {
                console.log("api catch username doesn't exist")
    
            }
        })
        .catch(err => {
            let msg = "Error updating user by username//eariler call"
            res.status(400).json({ msg: msg, err: "Error" });
            console.log(msg, err);
        })
}




app.use(express.static('./client'));

app.get("/users", getUserRoute)
app.get("/users/:username",getByUsernameRoute)
app.post("/users/addUser",addUserRoute)
app.post("/checkinghash/:username", hashingpassword)

app.post("/scores/gamec", updateGame_c)
app.post("/scores/gamew", updateGame_w)
app.post("/scores/gameh", updateGame_h)

app.use('/user/current', function(req,res,next) {
    console.log("session", req.session);
    console.log("current user", req.session.user);
    if ( req.session.user ) {
        //res.status(200).json(req.session.user);
        res.status(200).json({"msg": "Successful","session":req.session});
    }
    else {
        res.status(200).json({"msg": "You are not logged in"});
    }
});

app.get('/logout', function(req,res,next) {
    req.session.destroy();
    res.status(200).json({"msg": "You have logged out now"})
    console.log("logout success");
    res.redirect('/home.html');
});

//app.use('/', function(req, res) {
//    res.redirect("/home.html");
//} );




