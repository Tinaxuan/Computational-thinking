(function() {
    // add constants for each class created in the model
    const User = require("../shared/model.js").User;

    //everything needed to access the DB is contained within this module
    const config = require('../config-db.js');
    const MongoClient = require('mongodb').MongoClient;
    const fullurl = `mongodb://${config.username}:${config.password}@${config.url}:${config.port}/${config.database}?authSource=admin`;
    const sanitisedUrl = fullurl.replace(/:([^:@]{1,})@/, ':****@');
    const client = new MongoClient(fullurl, { useUnifiedTopology: true });

    const bcrypt = require('bcrypt');


    let collection = null;
    //let scoreCollection = null;
    //example code
    let userData = [
        {"_id": "xiaohe", password:bcrypt.hashSync("password",10),game_c:0,game_w:0,game_h:0},
        {"_id":"lisa",  password:bcrypt.hashSync("password",10),game_c:1, game_w:1, game_h:1},
	    {"_id":"mila", password:bcrypt.hashSync("password",10), game_c:2, game_w: 4, game_h: 5},
	    {"_id":"paul", password:bcrypt.hashSync("password",10), game_c:3, game_w: 3, game_h: 2}
    ]


    let init = function() {
        return client.connect()
            .then(conn => {
                //if the collection does not exist it will automatically be created
                //test if the collections work
                collection = client.db().collection(config.collection);
                //scoreCollection = client.db().collection(config.scoreCollection);
                console.log("Connected!", sanitisedUrl);
            })
            .catch(err => { console.log(`Could not connect to ${sanitisedUrl}`, err); throw err; })
            .then(() => collection.deleteMany()) // Delete whole table for user
            .then(() => collection.insertMany(userData))
            .then(res => console.log("User Data inserted with IDs", res.insertedIds))
            .catch(err => {
                console.log("Could not add data ", err.message);
                //For now, ingore duplicate entry errors, otherwise re-throw the error for the next catch
                if (err.name != 'BulkWriteError' || err.code != 11000) {
                    client.close();
                    console.log("Disconnected")
                    throw err;
                }
            })
    }

    // const getUsers = function(){
    //     return collection.find({}).toArray()//.project({ username: "$_id", _id: 0, password: 1}).toArray()
    //         .then(users => users.map(user => { user.username = user._id; return User.fromJSON(user);}))
    // }

    const getUsers = function(){
        return collection.find({}).project({ username: "$_id", _id: 0, password: 1,game_w:1,game_c:1,game_h:1}).toArray()
            
    }

    const getByUsername = function(username) {
        return collection.findOne({ _id: username })//, { projection: { username: "$_id", _id: 0, password: 1 } })
            .then(user => { if (user!=null) { user.username = user._id; } return User.fromJSON(user); })
    }
    const addUser = function(jsn) {
        jsn._id = jsn.username
        delete jsn.username
        return collection.insertOne(jsn)
            .then(result => result.insertedId)
    }

    // const getAllScoredata = function(game_number,level){
    //     return scoreCollection.find({game_id=game_number},{level_id = level}).sort({score:-1}).toArray()
    //         .then(score_data => score_data.map(score_data => Score.fromJSON(score_data)))
            
    // }
    
    // //it should return only one
    // const getScore = function(name,game_number,level) {
    //     return scoreCollection.findOne({game_id=game_number},{level_id =level}, {username = name})
    //         .then(score_data => score_data.map(score_data => Score.fromJSON(score_data)))
    // }

    // const addScoredata = function(jsn){ 
    //     const query = {username : jsn.username, game_id : jsn.game_id, level_id: jsn.level_id};
    //     const options = {upsert:true};
    //     return scoreCollection.updateOne(quert,jsn,options)
    //     ////?没懂
    //         .then(result => result.insertedId)    
    // }

    const updateGame_w = function(username, score) {
        return collection.updateOne({ _id: username }, {$set:{game_w:score }})
                    .then(result => result.modifiedCount)
                    //if result = 0, it has update successfully 

    }

    const updateGame_c = function(username, score) {
        return collection.updateOne({ _id: username }, {$set:{game_c:score }})
                    .then(result => result.modifiedCount)
                    //if result = 0, it has update successfully 

    }

    const updateGame_h = function(username, score) {
        return collection.updateOne({ _id: username }, {$set:{game_h:score }})
                    .then(result => result.modifiedCount)
                    //if result = 0, it has update successfully 

    }

    


    module.exports = {
        init : init, 
        getUsers : getUsers,
        getByUsername : getByUsername,
        addUser : addUser,
        updateGame_w : updateGame_w,
        updateGame_c : updateGame_c,
        updateGame_h : updateGame_h,
    };
})()