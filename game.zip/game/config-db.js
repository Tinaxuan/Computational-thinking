(function() {
	const db_info = {url:'pc7-030-l',
                        username: 'administer',
                        password: 'xuan_25',
                        port: '22741',
						database: 'msc_ct_games',
                        collection: 'user',
                        // scoreCollection: "scoredata"
                    };

	const moduleExports = db_info;

    if (typeof __dirname != 'undefined')
        module.exports = moduleExports;
}());
