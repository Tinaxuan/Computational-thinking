
// test get the level one map
var currentState = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 2, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 3, 0, 0, 0, 0, 0, 0, 0, 0]];
var workspace;
var currentToolbox = "toolbox1_w";
var max_level = 9;
//current user name
var current;
var isWin= false;


function preload() {
    character = loadImage("images/person_w.png");
    hinder = loadImage("images/monster.png")
    coin = loadImage("images/coin.png");
    bullet_img = loadImage("images/bullet_img.png");
    power = loadImage("images/power.png");
    target = loadImage("images/tar.png")
}


var game = {
    //start the game
    init: function () {
        //intialize the level page
        levels.init();
        workspace = Blockly.inject('toolboxdiv',
            {
                // media: 'https://unpkg.com/blockly/media/',
                toolbox: document.getElementById(currentToolbox),
                zoom: {
                    controls: true,
                    wheel: true,
                    startScale: 1.0,
                    maxScale: 3,
                    minScale: 0.5,
                    scaleSpeed: 1.05
                },
                trashcan: true,
                scrollBar: true

    
            });
        workspace.trashcan.setLidOpen(false);

        // game.workspace.updateToolbox(currentToolbox);

    },

//hide all the main screens and all the pop-up windows
    hideScreens: function () {
        //close all game layer screen
        var screens = document.getElementsByClassName("gamelayer");
        for (let i = screens.length - 1; i >= 0; i--) {
            var screen = screens[i];
            screen.style.display = "none";
        }
        //close all pop up screens

        var screens = document.getElementsByClassName("pop");
        for (let i = screens.length - 1; i >= 0; i--) {
            var screen = screens[i];
            screen.style.display = "none";
        }
    },

    hideScreen: function (id) {
        var screen = document.getElementById(id);
        screen.style.display = "none";
    },

    showScreen: function (id) {
        var screen = document.getElementById(id);
        screen.style.display = "block";
        screen.style.visibility = "visible";
    },

    // showInline: function (id) {
    //     var screen = document.getElementById(id);
    //     screen.style.display = "inline-block";
    // },

    showLevelScreen: function () {
        game.hideScreens();
        game.showScreen("levelselectscreen");
        workspace.clear();
        workspace.trashcan.emptyContents();
    },

    showMenuScreen: function () {
        game.hideScreens();
        game.showScreen("gamestartscreen");
        workspace.clear();
        workspace.trashcan.emptyContents();
    },

    start: function () {
        loop();
        game.hideScreens();
        game.showScreen("gamecanvas");
        if (game.currentLevel == 1) {
            document.getElementById("hint2Pop").style.display= "block";
        } else if (game.currentLevel == 2) {
            document.getElementById("hint3Pop").style.display= "block";
        } else if (game.currentLevel == 6) {
            document.getElementById("hint7Pop").style.display= "block";
        } else if (game.currentLevel == 8) {
            document.getElementById("hint9Pop").style.display= "block";
        } else if (game.currentLevel == 9) {
            document.getElementById("hint10Pop").style.display= "block";
        }
        redraw();
    }
};

// this is p5.js 
function setup() {
    var canvas = createCanvas(400, 480);
    canvas.parent("canvas");
    
    noLoop();
}

// this is also p5.js, it will draw the current state map (animate in loops) 
function draw() {
    // background('white');
    Map.draw(currentState);
    textSize(32);
    let pocket = document.getElementById("pocket");
    if (game.currentLevel == 7) {
        pocket.style.display = "block";
        pocket.innerHTML= "Bullet number : " + bullet;
        // image(bullet_img, 30, 14 * 30, 30, 30)
        // text(': ' + bullet, 70, 445);
    } else if (game.currentLevel == 8) {
        pocket.style.display = "block";
        pocket.innerHTML= "Coin number : " + coins;
        // image(coin, 30, 14 * 30, 30, 30)
        // text(': ' + coins, 70, 445);
    } else {
        pocket.style.display = "none";
        // erase();
        // rect(30, 14 * 30, 100, 100);
        // noErase();

    }
    
}


var levels = {
    data: [{
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 2, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox1_w",
        target: "Connect the blocks and reach the target",
        hint: "Connect the blocks"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 1, 1, 1, 1, 2, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox2_w",
        target: "Count the number of steps and enter the number in the block",
        hint: "Count the number of steps and enter the number in the block"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 2, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 0, 0, 0],
        [0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
        [0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
        [0, 0, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox3_w",
        target: "Use the repeat block to create the loops to reach the end",
        hint: "Recognize the pattern and repeat it"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 1, 0, 1, 0, 0],
        [0, 0, 0, 1, 1, 1, 0, 1, 0, 0],
        [0, 0, 0, 1, 0, 1, 0, 1, 0, 0],
        [0, 1, 1, 1, 0, 1, 0, 2, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox4_w",
        target: "Use the repeat block to create the loops to reach the end",
        hint: "You can always add extra line after the loop"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 1, 1, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 1, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 2, 0, 0]],
        toolbox: "toolbox5_w",
        target: "Use the repeat block to create the loops to reach the end",
        hint: "You can always add extra line before the loop"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 1, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 3, 0, 0, 0, 2, 1, 1, 0, 0]],
        toolbox: "toolbox6_w",
        target: "Use the loops to reach the end",
        hint: "Try to add more blocks before and after the loop"
    }, {
        map: [[0, 3, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 1, 1, 2],
        [0, 1, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 1, 0, 0, 0, 1, 1, 6, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 1, 1, 6, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 6, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox7_w",
        target: "Use the loops to reach the end",
        hint: "Check the place of the energy bar. Repeat the action while get one bar"
    },{
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 4, 1, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 4, 1, 1, 2, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox8_w",
        target: "Kill the monsters and Use the loops to reach the end",
        hint: "You should buy some bullet first (check the number). If you have bullets in pocket, it will automatically kill the monster when pass by. It takes one bullet for each monster"
    }, {
        map: [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 1, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 5, 0, 0],
        [0, 1, 0, 0, 2, 1, 1, 1, 0, 0],
        [0, 3, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox9_w",
        target: "Use the loops to reach the end",
        hint: "Find the time to get out of the loop. Change the while function to until."
    }, {
        map: [[0, 3, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 1, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 2, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 1, 1, 1, 1, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
        toolbox: "toolbox10_w",
        target: "Use the loops to reach the end",
        hint: "The first 1 is the start point and 5 is the end point. Every time the loop is ran, i will be increased by 1. The loop will end when it reach the end point 5"
    }],

    init: function () {
        var levelSelectScreen = document.getElementById("level_buttons");
        // handle the button click
        var buttonClickHandler = function () {
            game.hideScreen("levelselectscreen");
            levels.load(this.value - 1);
        };

        max_level = levels.data.length;

        //initial the buttons based on the available data
        for (let i = 0; i < levels.data.length; i++) {
            var button = document.createElement("input");
            button.className = "level_button";
            button.type = "button";
            button.value = (i + 1); // Level labels are 1, 2
            button.addEventListener("click", buttonClickHandler);
            levelSelectScreen.appendChild(button);
        }
    },
    // Load all data and images for a specific level
    load: function (number) {
        workspace.trashcan.emptyContents();
        //the currentMap should be loaded from the level entities
        currentMap = levels.data[number].map;
        // load the current toolbox id
        get_map(currentMap);
        var state = number + 1;
        document.getElementById("state").innerHTML= "Level : " + state;
        //console.log(currentMap);
        currentToolbox = levels.data[number].toolbox;
        game.currentLevel = number;
        document.getElementById("hint_message").innerHTML=levels.data[number].hint;
        document.getElementById("target_message").innerHTML=levels.data[number].target;
        workspace.updateToolbox(document.getElementById(currentToolbox));
        console.log(game.currentLevel);
        isWin = false;
        //load hint 2
        game.start();
    }
}


// this is how the map is drawn, read the array of array and create the map.
var Map = {
    draw: function (map) {
        strokeWeight(2);
        var height = 400 / map[0].length;
        var width = 400 / map.length; //actual height
        for (var i = 0; i < map.length; i++) {
            for (var j = 0; j < map[0].length; j++) {
                if (map[j][i] == 0) {
                    fill(159,105,72);
                    rect(i * height, j * width, height, width);


                } else if (map[j][i] == 2) {
                    fill("white");
                    image(target, i * height, j * width, height, width)


                } else if (map[j][i] == 1) {
                    fill("white");
                    rect(i * height, j * width, height, width);

                } else if (map[j][i] == 3) {
                    fill("white");
                    image(character, i * height, j * width, height, width)
                
                } else if (map[j][i] == 4) {
                    image(hinder, i * height, j * width, height, width)
                
                } else if (map[j][i] == 5) {
                    image(coin, i * height, j * width, height, width)
                
                } else if (map[j][i] == 6) {
                    image(power, i * height, j * width, height, width)
                
                } 

                noFill();
                stroke("grey");
                rect(i * height, j * width, height, width);
            }
        }
    }
}

var stepButton = null;

// start the page and the game when the web html has been load
//window.addEventListener("load", function () {
window.onload = function() {
    stepButton = document.getElementById('run');
    game.init();
    workspace.addChangeListener(function (event) {
        if (!(event instanceof Blockly.Events.Ui)) {
            // Something changed. Parser needs to be reloaded.
            generateCodeAndLoadIntoInterpreter();
        }
    });
     // Load the interpreter now, and upon future changes.
    generateCodeAndLoadIntoInterpreter();
    game.showLevelScreen();

    //login UI control
    // document.getElementById("login").onclick = () => login();
    // document.getElementById("register").onclick = () => toRegisteringHomepage();
    // document.getElementById("signup").onclick = () => getNewUserinfo();
    // document.getElementById("logout").onclick = () => logout();
    
    fetch('/user/current')
    .then(res => res.json())
    .then(jsn => {
        console.log("current user", jsn)
        current = jsn.session.user.name;
    });
}
//});


//Game UI control

function showHint() {
    var screen= document.getElementById("hint_screen");
    screen.style.display="block";

}

function showTarget() {
    var screen= document.getElementById("target_screen");
    screen.style.display="block";
}

function closePop() {
    var screens= document.getElementsByClassName("pop")
    for (let i = screens.length - 1; i >= 0; i--) {
        var screen = screens[i];
        screen.style.display = "none";
    }
}




function get_map(map) {
    for (var i = 0; i < map.length; i++) {
        for (var j = 0; j < map[0].length; j++) {
            currentState[j][i]= map[j][i];
        }
    }
}

function replay() {
    get_map(currentMap);
    myInterpreter = null;
    redraw();
    resetStepUi(true);
    closePop();
}


function next_level() {
    closePop();
    workspace.clear();
    workspace.trashcan.emptyContents();
    game.currentLevel += 1;
    levels.load(game.currentLevel);
}


function back_main() {
    game.hideScreens();
    game.showScreen("gamestartscreen");
}


async function update() {
    let response = await updateGame_w(current, game.currentLevel+1);
    return response;
}


