/// max_level is defined in game-fixed.js

var bullet = 0;
window.LoopTrap = 100;
var coins = 0;
var meet_coin = false;
var get_power = false;

//RL: refactored your code to avoid repetition - if you have questions please just ask
function move(j_offset, i_offset){
    var step = 1;
    for (var i=0;i<currentState.length;i++) {
        for (var j= 0; j< currentState[0].length;j++) {
            if (currentState[j][i] == 3) {
                if (step == 1) {
                    meet_coin = false;
                    get_power = false;
                    console.log(currentState);
                    //not wall or goal
//                     if ( currentState[j+j_offset][i+i_offset] !== 0 && currentState[j+j_offset][i+i_offset]!==2) {
//                         step--;
//                         //RL: moved the if from below - needs to be before your change [j][i+1] to 3
//                         if (currentState[j+j_offset][i+i_offset] == 4) { 
//                             bullet--;
//                         } else if (currentState[j+j_offset][i+i_offset] == 5) {
//                             meet_coin = true;
//                             coins ++;
//                         } else if (currentState[j+j_offset][i+i_offset] == 6) {
//                             get_power = true;
//                         } 
//                         currentState[j][i]=1;
//                         currentState[j+j_offset][i+i_offset]=3;
//                         //RL: This will never be true - you have just changed [j][i+1] to 3 so it will never be 4 here
// //                        if (currentState[j][i+1] == 4) { 
// //                            bullet--;
// //                        }
//                         console.log("go");
                    
//                     } else 
                    if (currentState[j+j_offset][i+i_offset] ==2 ) {
                        step--;
                        currentState[j][i]=1;
                        currentState[j+j_offset][i+i_offset]=3;
                        update();
                        // hideScreen("gamecanvas")
                        console.log("win")
                        isWin= true;
                        //restore
                        workspace.clear();
                        bullet = 0;
                        coins = 0;
                        if (game.currentLevel == 9) {
                            game.showScreen("end_of_game");
                            
                        } else {
                            game.showScreen("next"); 
                            workspace.trashcan.emptyContents();                          
                        }
                    }  else if (currentState[j+j_offset][i+i_offset] == 1) {
                        step--;
                        console.log("go");
                        currentState[j][i]=1;
                        currentState[j+j_offset][i+i_offset]=3;
                        

                    } else if (currentState[j+j_offset][i+i_offset] == 4) {
                        if (bullet >=1) {
                            step--;
                            bullet--;
                            currentState[j][i]=1;
                            currentState[j+j_offset][i+i_offset] =3;    
                        } else {
                            myInterpreter = null;
                            workspace.trashcan.emptyContents();
                            document.getElementById("message").innerHTML="You did not get enough bullets!"
                            game.showScreen("not_working");

                        }
                    
                    } else if (currentState[j+j_offset][i+i_offset] == 5 ) {
                        step--;
                        meet_coin = true;
                        coins ++;
                        currentState[j][i]=1;
                        currentState[j+j_offset][i+i_offset]=3;
                        
                    } else if (currentState[j+j_offset][i+i_offset] == 6 ) {
                        get_power = true;
                        step--;
                        currentState[j][i]=1;
                        currentState[j+j_offset][i+i_offset]=3;
                        
                    } else {
                        console.log(currentState);
                        console.log("bad")
                        if (isWin) {
                            return;
                        } else {
                            myInterpreter = null;
                            workspace.trashcan.emptyContents();
                            document.getElementById("message").innerHTML="You can not go this way"
                            game.showScreen("not_working");
                            //clear the interpreter and stop execution
                        }
                        // game.showScreen("not_working");
    
                    }

                }
                
            }
        }              
    }    
}

function moveright(){
    move(0,1);
    redraw();
}

function moveforward(){
    move(-1,0);
    redraw();
}

function moveleft() {
    move(0,-1);
    redraw();
}

function movedown() {
    move(1,0);
    redraw();
}

function move_forward_steps(steps) {
    for (var i=0; i<steps;i++){
        //RL: removed timeout because it interferes with other timeouts
        moveforward();
        redraw();
    }
}

function move_right_steps(steps) {
    for (var i=0; i<steps;i++){
        //RL: removed timeout because it interferes with other timeouts
        moveright();
        redraw();
    }
}

function move_down_steps(steps) {
    for (var i=0; i<steps;i++){
        //RL: removed timeout because it interferes with other timeouts
        movedown();
        redraw();
    }
}

function move_left_steps(steps) {
    for (var i=0; i<steps;i++){
        //RL: removed timeout because it interferes with other timeouts
        moveleft();
        redraw();
    }
}
function getBullets(number) {
    bullet = number;
    console.log("buy bullets", bullet);
}

function haveBullets() {
    console.log("have bullets", bullet);
    if (bullet > 0) {
        console.log(true);
        return true;
    } else {
        return false;
    }

}

function meetCoin() {
    return meet_coin;
}

function getPower() {
    return get_power;
}

function checkInfiniteLoop() {
    if(--window.LoopTrap <= 0) { 
        // alert("Too many loops! Please try again");
        game.showScreen("not_working");
        throw "Infinite loop."; 
    }
}