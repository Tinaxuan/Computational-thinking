var myInterpreter = null;

// The interpreter of blockly
function initApi(interpreter, scope) {
    // the wrapper is let the interpreter understand the customized code.
    var wrapper;
    wrapper = function (id) {
        moveright();
    };
    interpreter.setProperty(scope, 'moveright',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        moveleft();
    };
    interpreter.setProperty(scope, 'moveleft',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        move_forward_steps(id);
    };
    interpreter.setProperty(scope, 'move_forward_steps',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        move_right_steps(id);
    };
    interpreter.setProperty(scope, 'move_right_steps',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        move_down_steps(id);
    };
    interpreter.setProperty(scope, 'move_down_steps',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        move_left_steps(id);
    };
    interpreter.setProperty(scope, 'move_left_steps',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        getBullets(id);
    };
    interpreter.setProperty(scope, 'getBullets',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        //RL: Missing return statement!!!
        return haveBullets()
    };
    
    interpreter.setProperty(scope, 'haveBullets',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        //RL: Missing return statement!!!
        return meetCoin();
    };
    
    interpreter.setProperty(scope, 'meetCoin',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        return getPower();
    };
    
    interpreter.setProperty(scope, 'getPower',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        moveforward();
    };
  
    interpreter.setProperty(scope, 'moveforward',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        movedown();
    };
    interpreter.setProperty(scope, 'movedown',
        interpreter.createNativeFunction(wrapper));
    
    wrapper = function (id) {
        id = id ? id.toString() : '';
        try { return interpreter.createPrimitive(highlightBlock(id)); }
        catch (e) { console.log("Could not highlight", id); }
    };
    interpreter.setProperty(scope, 'highlightBlock',
        interpreter.createNativeFunction(wrapper));

    wrapper = function() {
        checkInfiniteLoop();
    }

    interpreter.setProperty(scope, 'checkInfiniteLoop',
        interpreter.createNativeFunction(wrapper));
}


var highlightPause = false;
var latestCode = '';
var hascode = true;

// highlight the running code
function highlightBlock(id) {
    workspace.highlightBlock(id);
    highlightPause = true;
}

// stop hightlight any of the code
function resetStepUi(clearOutput) {
    workspace.highlightBlock(null);
    highlightPause = false;

}

function generateCodeAndLoadIntoInterpreter() {
    // Generate JavaScript code and parse it.
    Blockly.JavaScript.STATEMENT_PREFIX = 'highlightBlock(%1);\n';
    Blockly.JavaScript.addReservedWords('highlightBlock');
    Blockly.JavaScript.INFINITE_LOOP_TRAP = 'checkInfiniteLoop();\n';
    latestCode = Blockly.JavaScript.workspaceToCode(workspace);
    resetStepUi(true);
}

function runCode() {
    generateCodeAndLoadIntoInterpreter();
    //when first initalizing the interpreter
    if (!myInterpreter) {
        myInterpreter = new Interpreter(latestCode, initApi);
        alert('Ready to execute the following code\n' +
            '===================================\n' + latestCode);
    }

    try {
        nextStep();
        // document.getElementById("run").style.display = "none"
        // document.getElementById("retry").style.display = "block"
    } catch (error) {
        //if there is anything that the interpreter could not solve
        replay();
        game.showScreen("not_working");
        console.log("interperter error")
    }

    nextStep();

    function nextStep() {
        if (myInterpreter.step()) {
            setTimeout(nextStep, 10);
            redraw();
        } else {

            // console.log(currentState);
            // when there is no steps left
            // check_if_win();

            setTimeout(()=> {
                if (!isWin) {
                    console.log("Need more blocks")
                    // replay();
                    document.getElementById("message").innerHTML="You did not reach the target. Try add more blocks"
                    game.showScreen("not_working");
                    workspace.trashcan.emptyContents();
                } else {
                    myInterpreter = null;
                }
            }, 150);

            // if (!isWin) {
            //     console.log("Need more blocks")
            //     replay();
            //     game.showScreen("not_working");
            // } else {
            //     myInterpreter = null;
            // }

        }
    }
}



function stepCode() {
    if (!myInterpreter) {
        // First statement of this code.
        // Clear the program output.
        resetStepUi(true);
        myInterpreter = new Interpreter(latestCode, initApi);
//        alert('Ready to execute the following code\n' +
//        '===================================\n' + latestCode);

        // And then show generated code in an alert.
        // In a timeout to allow the outputArea.value to reset first.
        setTimeout(function () {
            alert('Ready to execute the following code\n' +
                '===================================\n' + latestCode);
            highlightPause = true;
            stepCode();
        }, 1);
        //return;
    }
    highlightPause = false;
    console.log(currentState);
    do {
        try {
            var hasMoreCode = myInterpreter.step();
        } finally {
            if (!hasMoreCode) {
                // Program complete, no more code to execute.
                hascode = false;
                myInterpreter = null;
                resetStepUi(false);

                // Cool down, to discourage accidentally restarting the program.
                //stepButton.disabled = 'disabled';
                // setTimeout(function () {
                //     stepButton.disabled = '';
                // }, 2000);
                //return;
            }
        }
        // Keep executing until a highlight statement is reached,
        // or the code completes or errors.
    } while (hasMoreCode && !highlightPause);
}

