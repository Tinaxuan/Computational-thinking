Blockly.Blocks['moveforeward_one_step'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("Move up one step");
        this.setInputsInline(false);
        this.setPreviousStatement(true, null);
          this.setNextStatement(true, null)
      this.setColour(315);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

Blockly.Blocks['moveright_one_step'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("Move right one step");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['moveleft_one_step'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("Move left one step");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['movedown_one_step'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("Move down one step");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};


Blockly.Blocks['move_forward'] = {
    init: function() {
      this.appendValueInput("Steps")
          .setCheck("Number")
          .appendField("Move up");
      this.appendDummyInput()
          .appendField("steps");
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(285);
   this.setTooltip("The number is the number of steps to move");
   this.setHelpUrl("");
    }
  };

  Blockly.Blocks['move_right'] = {
    init: function() {
      this.appendValueInput("Steps")
          .setCheck("Number")
          .appendField("move right for");
      this.appendDummyInput()
          .appendField("steps");
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(285);
   this.setTooltip("The number is the number of steps to move");
   this.setHelpUrl("");
    }
  };

  Blockly.Blocks['move_down'] = {
    init: function() {
      this.appendValueInput("Steps")
          .setCheck("Number")
          .appendField("move down for");
      this.appendDummyInput()
          .appendField("steps");
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(285);
   this.setTooltip("The number is the number of steps to move");
   this.setHelpUrl("");
    }
  };

  Blockly.Blocks['move_left'] = {
    init: function() {
      this.appendValueInput("Steps")
          .setCheck("Number")
          .appendField("move left for");
      this.appendDummyInput()
          .appendField("steps");
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(285);
   this.setTooltip("The number is the number of steps to move");
   this.setHelpUrl("");
    }
  };

  //RL: this block is called 'have_bullets' so do not allow the user to select other variables
  Blockly.Blocks['have_bullets'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("Have bullet in the pocket");
/*      this.appendDummyInput()
          .appendField(new Blockly.FieldVariable("bullet"), "Bullet");
      this.appendDummyInput()
          .appendField("in the pocket");
*/
      this.setOutput(true, "Boolean");
      this.setInputsInline(true);
      this.setColour(150);
      this.setTooltip("");
      this.setHelpUrl("");
    }
  };

  Blockly.Blocks['buy_bullets'] = {
    init: function() {
      this.appendValueInput("Bullets")
          .setCheck("Number")
          .appendField("Buy");
      this.appendDummyInput()
          .appendField("bullets");
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(285);
   this.setTooltip("The number is the number of bullets to buy");
   this.setHelpUrl("");
    }
  };

  

  //RL: don't let the user select something else - only bullet
  Blockly.Blocks['variables_bullet'] = {
    init: function() {
      this.appendDummyInput()
        .appendField("bullet");
      this.setOutput(true, 'Number');
    }
  };

  Blockly.Blocks['meet_coin'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("There is a coin");
/*      this.appendDummyInput()
          .appendField(new Blockly.FieldVariable("bullet"), "Bullet");
      this.appendDummyInput()
          .appendField("in the pocket");
*/
      this.setOutput(true, "Boolean");
      this.setInputsInline(true);
      this.setColour(150);
      this.setTooltip("");
      this.setHelpUrl("");
    }
  }

  Blockly.Blocks['get_power'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("have a energy bar");
      this.setOutput(true, "Boolean");
      this.setInputsInline(true);
      this.setColour(150);
      this.setTooltip("");
      this.setHelpUrl("");
    }
  }

  Blockly.Blocks['repeat_forever'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("Repeat forever");
      this.appendValueInput("movement")
          .setCheck(null)
          .appendField("Do");
      this.setInputsInline(false);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(120);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

  

  Blockly.JavaScript['get_power'] = function(block) {
    var code = "getPower()";
    return [code, Blockly.JavaScript.ORDER_FUNCTION_CALL];
  }

  Blockly.JavaScript['meet_coin'] = function(block) {
    var code = "meetCoin()";
    return [code, Blockly.JavaScript.ORDER_FUNCTION_CALL];
  }

  Blockly.JavaScript['variables_bullet'] = function(block) {
    //RL: don't use a blockly variable - use the bullet variable from your game
    // TODO: Assemble JavaScript into code variable.
    //var variable_name = Blockly.JavaScript.nameDB_.getName(block.getFieldValue('Bullet'), Blockly.Variables.NAME_TYPE); ;
    //return [variable_name + "", Blockly.JavaScript.ORDER_ATOMIC];
    return ["bullet", Blockly.JavaScript.ORDER_ATOMIC]
  };



  

  Blockly.JavaScript['have_bullets'] = function(block) {
    // TODO: Assemble JavaScript into code variable.
//    var variable_name = Blockly.JavaScript.nameDB_.getName(block.getFieldValue('Bullet'), Blockly.Variables.NAME_TYPE); ;
    
//    console.log("this is the variable_name:", variable_name);
//    return [variable_name + ">" + 0, Blockly.JavaScript.ORDER_RELATIONAL];
      var code = "haveBullets()";
      return [code, Blockly.JavaScript.ORDER_FUNCTION_CALL];
  };

  Blockly.JavaScript['buy_bullets'] = function(block) {
    // TODO: Assemble JavaScript into code variable.
    var Bullets  = Blockly.JavaScript.valueToCode(block, 'Bullets', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'getBullets('+ Bullets +');\n';
    return code;
  };

  Blockly.JavaScript['move_left'] = function(block) {
    var steps = Blockly.JavaScript.valueToCode(block, 'Steps', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'move_left_steps('+ steps +');\n';
    return code;
  };

  Blockly.JavaScript['move_down'] = function(block) {
    var steps = Blockly.JavaScript.valueToCode(block, 'Steps', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'move_down_steps('+ steps +');\n';
    return code;
  };

  Blockly.JavaScript['move_right'] = function(block) {
    var steps = Blockly.JavaScript.valueToCode(block, 'Steps', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'move_right_steps('+ steps +');\n';
    return code;
  };

  Blockly.JavaScript['move_forward'] = function(block) {
    var steps = Blockly.JavaScript.valueToCode(block, 'Steps', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'move_forward_steps('+ steps +');\n';
    return code;
  };
  

Blockly.JavaScript['moveright_one_step'] = function(block) {
        var code = 'moveright(); \n';
        return code;
    }

Blockly.JavaScript['moveleft_one_step'] = function(block) {
        var code = 'moveleft(); \n';
        return code;
}


Blockly.JavaScript['moveforeward_one_step'] = function(block) {
    // TODO: Assemble JavaScript into code variable.
    var code = 'moveforward()\n';
    return code;
};

Blockly.JavaScript['movedown_one_step'] = function(block) {
    var code = 'movedown(); \n';
    return code;
}

