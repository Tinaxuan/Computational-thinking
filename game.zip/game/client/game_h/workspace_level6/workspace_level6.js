var score  = 0;
var username;

document.getElementById("level6").onclick = function () {
  showLevel(6)
  // modal6.style.display = "block";
}


//popup screen
//tip screen
var modal6 = document.getElementById("Tipmodel6");


// get button
var modalBtn6= document.getElementById("tip6");

// button to close
var closeBtn6 =  document.getElementsByClassName("closeBtn6")[0];

var footer = document.getElementsByClassName("modal-footer6")[0];

footer.addEventListener("click",closeModal);

modalBtn6.addEventListener("click",openModal);

closeBtn6.addEventListener("click",closeModal);

window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal6.style.display = "block";

	
}

// close screen
function closeModal () {
	modal6.style.display = "none";

}

// outsideClick
function outsideClick (e) {
	if(e.target == modal6){
		modal6.style.display = "none";

	}
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal6 = document.getElementById("passTipmodel6");
// button to close
var passcloseBtn6 =  document.getElementsByClassName("passcloseBtn6")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes6 = getDOM("passYes6");
var passNo6 = getDOM("passNo6");

passYes6.addEventListener("click", openNextLevel6);
passNo6.addEventListener("click", stayThisLevel6);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn6.addEventListener("click",closePassModal6);

window.addEventListener("click",passOutsideClick6);


//open leaderBoard.html
function openNextLevel6(){
  closePassModal6();
  window.location = "leaderBoard.html";
  // window.location = "home.html";
  
}

//stay this level
function stayThisLevel6(){
  closePassModal6();
  showLevel(6);
  
}
// popup screen
function openPassModal6 () {
	passmodal6.style.display = "block";	
}

// close screen
function closePassModal6 () {
	passmodal6.style.display = "none";
}

// outsideClick
function passOutsideClick6 (e) {
	if(e.target == passmodal6){
		passmodal6.style.display = "none";
	}
}





var functionStep = []
var timer_level6 = []
var meetSnake = false;
var canMove = false;
var iserror = false;
const snakePosition = {
  1:[0,240],
  2:[420,180]
}
const canMovePostion = {
  rode1:{
    top: [0, 0],
    left: [0, 240]
  },
  rode2:{
    top: [60, 360],
    left: [180, 240]
  },
  rode3: {
    top: [420, 420],
    left: [180, 420]
  }
}
function level6_move_forward(id, move_length, direction, timers, doUntil, test) {
  if (direction == 'left' || direction == 'top') {
    move_length = - move_length
  }
  var nowPositionTop = getDOM(id).offsetTop;
  var nowPositionLeft = getDOM(id).offsetLeft;
  var nextPositionTop = nowPositionTop;
  var nextPositionLeft = nowPositionLeft;
  if (direction == 'bottom' || direction == 'top') {
    nextPositionTop = nextPositionTop + move_length;
  } else {
    nextPositionLeft = nextPositionLeft + move_length;
  }
  for(var i in snakePosition){
    if (nextPositionTop == snakePosition[i][0] && nextPositionLeft == snakePosition[i][1]){
      meetSnake = true
      
      
      if (doUntil){
        
        return
      }
      iserror = true
      getDOM(id).style.top = nextPositionTop + 'px'
      getDOM(id).style.left = nextPositionLeft + 'px'
      if(!test){
        failed(timers, 'meet snake！');
      }
      return
    }
  }
  canMove = false;
  // debugger
  for (var i in canMovePostion) {
    const top = canMovePostion[i].top;
    const left = canMovePostion[i].left;
    if ((nextPositionTop >= top[0] && nextPositionTop <= top[1]) && (nextPositionLeft >= left[0] && nextPositionLeft <= left[1]) ){
      canMove = true
    }
  }
  if (canMove){
    getDOM(id).style.top = nextPositionTop + 'px'
    getDOM(id).style.left = nextPositionLeft + 'px'
    if(!test){
      if (getDOM(id).offsetLeft == 420 && getDOM(id).offsetTop == 420) {
        // if (doUntil) {
          setTimeout(() => {
            score = 6;
            update();
            //alert("Congruadation! Rright! \n You can check your score through the leader board.");
            // var r= confirm("Congratulation! You passed the level6! \n Do you want to go to the leader board?");
            // if (r==true){
            //   window.location = "leaderBoard.html";
            // }else{
            //   showLevel(6);
            // }
            openPassModal6();

          },  100);
        // } else {
          // getDOM('level6_frog').style.left = 0 + 'px';
          // getDOM('level6_frog').style.top = 0 + 'px';
          // getDOM('level6_frog').style.transform = getDOM('level6_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
          // timer_level6 = []
      
        }
    }
  }else if(getDOM(id).offsetLeft > 420 || getDOM(id).offsetTop >420){
    iserror = true
    if (!test){
      failed(timers, 'move too much！');
      return
    }
  }else if(getDOM(id).offsetLeft < 420 || getDOM(id).offsetTop < 420){
    iserror = true
    if (!test){
      failed(timers, 'KEEP MOVING TO DESTINATION！');
      return
    }
  }
}
// function level6_move_forward(id, move_length, direction, timers, doUntil) {
//   if (direction == 'left' || direction == 'top') {
//     move_length = - move_length
//   }
//   var nowPositionTop = getDOM(id).offsetTop;
//   var nowPositionLeft = getDOM(id).offsetLeft;
//   var nextPositionTop = nowPositionTop;
//   var nextPositionLeft = nowPositionLeft;
//   if (direction == 'bottom' || direction == 'top') {
//     nextPositionTop = nextPositionTop + move_length;
//   } else {
//     nextPositionLeft = nextPositionLeft + move_length;
//   }
//   for(var i in snakePosition){
//     if (nextPositionTop == snakePosition[i][0] && nextPositionLeft == snakePosition[i][1]){
//       meetSnake = true
//       if (doUntil){
//         return
//       }
//       failed(timers, 'meet snake！');
//       return
//     }
//   }
  
//   for (var i in canMovePostion) {
//     const top = canMovePostion[i].top;
//     const left = canMovePostion[i].left;
//     if ((nextPositionTop >= top[0] && nextPositionTop <= top[1]) && (nextPositionLeft >= left[0] && nextPositionLeft <= left[1]) ){
//       canMove = true
//     }
//   }
//   if (canMove){
//     getDOM(id).style.top = nextPositionTop + 'px'
//     getDOM(id).style.left = nextPositionLeft + 'px'
//     if (getDOM(id).offsetLeft == 280 && getDOM(id).offsetTop == 280) {
//       if (doUntil){
//         setTimeout(() => {
//           alert("Congruadation! Rright!");
//         }, 100);
//       }else{
//         getDOM('level6_frog').style.left = 0 + 'px';
//         getDOM('level6_frog').style.top = 0 + 'px';
//         getDOM('level6_frog').style.transform = getDOM('level6_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
//         timer_level6 = []
//       }
//     }
//   }else{
//     failed(timers, 'move to much！');
//     return
//   }
  
// }
function analysisCode_level6(code, doUntil, test) {
  
  code.forEach((move,index) => {
    var timeout = timer_level6.length * 100
    let timer = '';
    if(iserror){
      return
    }
    if (move == 'move_forward') {
      if (test){
        level6_move_forward('level6_frog', 60, getDirection('level6_frog'), timer_level6, doUntil, test);
        if (doUntil && meetSnake){
          return
        }
        functionStep.push('#move_forward')
      }else{
        timer = setTimeout(() => {
          level6_move_forward('level6_frog', 60, getDirection('level6_frog'), timer_level6, doUntil, test);
        },timeout)
        timer_level6.push(timer)
      }
    } else if (move == 'left') {
      if (test) {
        turnElement('level6_frog', getTurnDeg('left'))
        functionStep.push('#left')
      } else {
        timer = setTimeout(() => {
          turnElement('level6_frog', getTurnDeg('left'))
          
        }, timeout)
        timer_level6.push(timer)
      }
      // timer = setTimeout(() => {
        
      // }, timeout);
    } else if (move == 'right') {
      if (test) {
        turnElement('level6_frog', getTurnDeg('right'))
        functionStep.push('#right')
      } else {
        timer = setTimeout(() => {
          turnElement('level6_frog', getTurnDeg('right'))
        }, timeout)
        timer_level6.push(timer)
      }
      // timer = setTimeout(() => {
        
      // }, timeout);
    }
    // timer_level6.push(timer)
  });
  // if (doUntil){
  //   return new Promise(resolve => {
  //     setTimeout(() => resolve("finish"), timer_level6.length*100);
  //   });
  // }else{
  //   return
  // }
}

var demoWorkspace6 = Blockly.inject('gamelevel6',
  {
    media: 'https://unpkg.com/blockly/media/',
    toolbox: document.getElementById('toolboxh_6'),
    zoom: {
      controls : true, 
      wheel : true, 
      startScale : 1, 
      maxScale : 3, 
      minScale : 0.3, 
      scaleSpeed : 1.2
    }
  });
Blockly.Xml.domToWorkspace(document.getElementById('gamelevel6'),
  demoWorkspace6);


//before meeting code :before_meetingStartdo_start' + statements_1 + 'do_enddo_untilEnd'
//repeat: 'loopStart' + 'timeStart' + code + 'timeEnd' + statements_1 + 'loopEnd';
function analysisRepeatAndBefore(code) {
  console.log("level1:",code);
  var moves = code.split('before_meetingStart');
  var moves2 = []
  moves.forEach(item => {
    if (item && item.indexOf('do_untilEnd') > -1) {
      moves2 = moves2.concat(item.split('do_untilEnd'))
    } else {
      moves2 = moves2.concat(item)
    }
  })
  var moves3 = [] 
  moves2.forEach(item=>{
    var moves = item.split('loopStart');
    moves.forEach(item2 => {
      if (item2 && item2.indexOf('loopEnd') > -1) {
        moves3 = moves3.concat(item2.split('loopEnd'))
      } else {
        moves3 = moves3.concat(item2)
      }
    })

  })
  return moves3
}

//moves3(before meeting): do_start' + statements_1 + 'do_untilEnd'
var nowPosition=[];
var doUntilTimer  = 1;
async function check6() {
  var code = Blockly.JavaScript.workspaceToCode(demoWorkspace6);
  var moves = analysisRepeatAndBefore(code)
  function movesFunction(moves,test) {
    moves.forEach((item, index) => {
      const timeout = doUntilTimer * 1
      if (item.indexOf('timeStart') > -1) {
        // setTimeout(() => {
        //   console.log('1111111')
        const times = item.split('timeStart')[1].split('timeEnd')[0];
        for (let i = 0; i < times; i++) {
          analysisCode_level6((item.split('timeEnd')[1] || '').split('#'),false, test)
        }
        //   doUntilTimer++
        // }, timeout);
      } else if (item.indexOf('do_start') > -1) {
        meetSnake = false
        // var index = 0;
        // setTimeout(async() => {
        while (!meetSnake && index < 99 && !iserror) {
          // var result = await 
          if (index == 98) {
            alert(' BEFORE_REPEAT error!')
            return
          }
          analysisCode_level6((item.split('do_start')[1].split('do_end')[0] || '').split('#'), true, test);
          index++
        }
        // }, timeout);


        // if(){

        // }

      } else {
        // setTimeout(() => {
        //   console.log('3333333333333')
        //   doUntilTimer++
        analysisCode_level6(item.split('#'), false, test)
        // }, timeout);

      }
    })
  }
  movesFunction(moves, true);
  console.log(functionStep)
  meetSnake = false
  iserror = false
  canMove = false
  getDOM('level6_frog').style.left = 0 + 'px';
  getDOM('level6_frog').style.top = 0 + 'px';
  getDOM('level6_frog').style.transform = getDOM('level6_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
  
  movesFunction(functionStep);
  let checkResultTimer = setTimeout(() => {
    var nowTop = getDOM('level6_frog').offsetTop
    var nowLeft = getDOM('level6_frog').offsetLeft
    if (nowTop < 420 || nowLeft < 420) {
      failed(timer_level6, 'KEEP MOVIGN TO DESTINATION！')
    }
  }, timer_level6.length * 100);
  timer_level6.push(checkResultTimer)
  // debugger
  // test(code);
  getDOM("level6_run").innerHTML = 'reset'
  getDOM("level6_run").onclick = function () {
    meetSnake = false
    iserror = false
    canMove = false
    functionStep = []
    getDOM("level6_run").onclick = check6;
    getDOM('level6_frog').style.left = 0 + 'px';
    getDOM('level6_frog').style.top = 0 + 'px';
    getDOM("level6_run").innerHTML = 'run';
    getDOM('level6_frog').style.transform = getDOM('level6_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
    timer_level6 = []
  }
  return;
}

getDOM("level6_run").onclick = check6



async function update() {
  let response = await updateGame_h(username, score);
  return response;
}

window.onload = function() {
  fetch('/user/current')
  .then(res => res.json())
  .then(jsn => {
  console.log("current user", jsn)
  username = jsn.session.user.name;
  console.log("level6_username:",username);
  })
}