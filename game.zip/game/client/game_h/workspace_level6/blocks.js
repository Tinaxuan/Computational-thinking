Blockly.Blocks['before_meeting'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Before meeting nakes ");
    this.appendStatementInput("before_meeting")
        .setCheck(null)
        .appendField("repeat: ");
    this.setInputsInline(false);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};




