Blockly.JavaScript['before_meeting'] = function (block) {
  var statements_1 = Blockly.JavaScript.statementToCode(block, 'before_meeting');
  return 'before_meetingStartdo_start' + statements_1 + 'do_enddo_untilEnd';
};


// do_untilStartdo_start