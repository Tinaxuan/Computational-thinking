Blockly.Blocks['frog_eggs'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/frogEgg.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['tadpole'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/tadpole.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['tadpole_withlegs'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/tapole.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['young_frog'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/tadpolewithlegs.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['frog'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/frog.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['food_sunshine'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level2/media/sunshine.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['temperature'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("appropriate temperature");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['step1'] = {
  init: function() {
    this.appendValueInput("name")
        .setCheck(null)
        .appendField("frog eggs");
    this.appendStatementInput("action")
        .appendField("if they have");
    this.appendValueInput("then")
        .setCheck(null)
        .appendField("they become");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['step2'] = {
  init: function() {
    this.appendValueInput("name")
        .setCheck(null)
        .appendField("tadpole");
    this.appendStatementInput("action")
        .setCheck(null)
        .appendField("if they");
    this.appendValueInput("then")
        .setCheck(null)
        .appendField("they become");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};
Blockly.Blocks['step3'] = {
  init: function() {
    this.appendValueInput("name")
        .setCheck(null)
        .appendField("tadpole  with legs");
    this.appendStatementInput("action")
        .setCheck(null)
        .appendField("if they");
    this.appendValueInput("then")
        .setCheck(null)
        .appendField("they become");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['step4'] = {
  init: function() {
    this.appendValueInput("name")
        .setCheck(null)
        .appendField("young frog");
    this.appendStatementInput("action")
        .setCheck(null)
        .appendField("if they");
    this.appendValueInput("then")
        .setCheck(null)
        .appendField("they become");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['stepall'] = {
  init: function() {
    this.appendValueInput("name1")
        .setCheck(null)
        .appendField("frog eggs");
    this.appendStatementInput("action1")
        .appendField("if they have");
    this.appendValueInput("last 1")
        .setCheck(null)
        .appendField("then they become");
    this.appendStatementInput("action2")
        .appendField("if they ");
    this.appendValueInput("last 2")
        .setCheck(null)
        .appendField("then they become");
    this.appendStatementInput("action3")
        .appendField("if they ");
    this.appendValueInput("last 3")
        .setCheck(null)
        .appendField("then they become");
    this.appendStatementInput("action4")
        .appendField("if they ");
    this.appendValueInput("last 4")
        .setCheck(null)
        .appendField("then they become");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['leaveWater'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("leave water");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour("rgb(97, 24, 126)");
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['food_plankton'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/image/foodPlankton.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['eat'] = {
  init: function() {
    this.appendValueInput("question_img")
        .setCheck(null)
        .appendField("eat");
    this.setPreviousStatement(true, null);
    this.setColour("rgb(97, 24, 126)");
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['water'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("water");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

// Blockly.Blocks['food_temperature'] = {
//   init: function() {
//     this.appendDummyInput()
//         .appendField("appropriate temperature");
//     this.setOutput(true, null);
//     this.setColour(0);
//  this.setTooltip("");
//  this.setHelpUrl("");
//   }
// };

Blockly.Blocks['sunshine'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("sunshine");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(0);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};