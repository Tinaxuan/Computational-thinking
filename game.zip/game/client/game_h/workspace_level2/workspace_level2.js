//level2 
/* Inject your workspace */ 
// var workspace2 = Blockly.inject('gamelevel2', options2);

var score  = 0;
var username;


var workspace2 = Blockly.inject('gamelevel2',
  {
    media: 'https://unpkg.com/blockly/media/',
    toolbox: document.getElementById('toolboxh_2'),
    zoom: {
      controls : true, 
      wheel : true, 
      startScale : 1, 
      maxScale : 3, 
      minScale : 0.3, 
      scaleSpeed : 1.2
    }
  });


/* Load Workspace Blocks from XML to workspace. Remove all code below if no blocks to load */
	
/* TODO: Change workspace blocks XML ID if necessary. Can export workspace blocks XML from Workspace Factory. */
workspaceBlocks = document.getElementById("workspaceBlocksh_2"); 


/* Load blocks to workspace. */
Blockly.Xml.domToWorkspace(workspaceBlocks, workspace2);


//level2 clicked
document.getElementById("level2").onclick = function(){
	showLevel(2)
	// getDOM("Tipmodel2").style.display = "block";

}


// document.getElementById("back1").addEventListener("click", button_click_back);

// function button_click_back(){
// 	window.location = "index.html";
// }
//popup screen
//tip screen
var modal2 = getDOM("Tipmodel2");


// get button
var modalBtn2= document.getElementById("tip2");

// button to close
var closeBtn2 = document.getElementsByClassName("closeBtn2")[0];


//footer to close
var footer = document.getElementsByClassName("modal-footer2")[0];

footer.addEventListener("click",closeModal);


modalBtn2.addEventListener("click",openModal);

closeBtn2.addEventListener("click",closeModal);

window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal2.style.display = "block";
	// getDOM("gamelevel2").style = "invisible";
	// modal2.style.visibility = "visible";
}

// close screen
function closeModal () {
	modal2.style.display = "none";
}

// outsideClick
function outsideClick (e) {
	if(e.target == modal2){
		modal2.style.display = "none";
	}
}




// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal2 = document.getElementById("passTipmodel2");
// button to close
var passcloseBtn2 =  document.getElementsByClassName("passcloseBtn2")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes2 = getDOM("passYes2");
var passNo2 = getDOM("passNo2");

passYes2.addEventListener("click", openNextLevel2);
passNo2.addEventListener("click", stayThisLevel2);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn2.addEventListener("click",closePassModal2);

window.addEventListener("click",passOutsideClick2);


//open next level
function openNextLevel2(){
  closePassModal2();
  showLevel(3);
  
}

//stay this level
function stayThisLevel2(){
  closePassModal2();
  showLevel(2);
  
}
// popup screen
function openPassModal2 () {
	passmodal2.style.display = "block";	
}

// close screen
function closePassModal2 () {
	passmodal2.style.display = "none";
}

// outsideClick
function passOutsideClick2 (e) {
	if(e.target == passmodal2){
		passmodal2.style.display = "none";
	}
}


function button_click2(){
    var code = Blockly.JavaScript.workspaceToCode(workspace2);
    console.log("button2_Click",code);
    console.log("-----");
    
    console.log("----" + code.match("no"))

    if(code.match("no")== null && code.match("yes") != null){

        score = 2;
        update();
        // alert("Congruadation! Rright! \n You can check your score through the leader board.");
        // var r= confirm("Congratulation!You passed the LEVEL 2! \n Go to the Level 3?");
        // if (r==true){
        //     showLevel(3);
        //   }else{
        //     showLevel(2);
        //   }
      openPassModal2();
    }else{
        alert("Try Again！");
    }
}

document.getElementById("check_button2").addEventListener("click", button_click2);



async function update() {
	let response = await updateGame_h(username, score);
	return response;
  }
  
  window.onload = function() {
	fetch('/user/current')
	.then(res => res.json())
	.then(jsn => {
	console.log("current user", jsn)
	username = jsn.session.user.name;
	console.log("level1/2_username:",username);
	})
  }