
Blockly.JavaScript['step1'] = function(block) {
  var value_name= Blockly.JavaScript.valueToCode(block, 'name', Blockly.JavaScript.ORDER_ATOMIC);
  console.log('here');
  var statements_action = Blockly.JavaScript.statementToCode(block, 'action').trim();
  var value_then = Blockly.JavaScript.valueToCode(block, 'then', Blockly.JavaScript.ORDER_ATOMIC).trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_name == "(#frog_eggs)" && 
  (statements_action == "#water#apporateTemperature" || statements_action == "#apporateTemperature#water")&& value_then == "(#tadpole)");
  
  console.log("step1,code",code);
  console.log("value_name",value_name);

  if(code){
    return "yes";
  }else{
    return "no";
  }
};

Blockly.JavaScript['step2'] = function(block) {
  var value_name = Blockly.JavaScript.valueToCode(block, 'name', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action= Blockly.JavaScript.statementToCode(block, 'action').trim();
  var value_then = Blockly.JavaScript.valueToCode(block, 'then', Blockly.JavaScript.ORDER_ATOMIC).trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_name == "(#tadpole)" && 
  statements_action == "#eat(#food_plankton)"  && value_then == "(#tadpole_withlegs)");
  
  console.log("step2,code:",code);
  console.log("value_name:",value_name);
  console.log("statements_action:", statements_action);
  console.log("value_then:",value_then);

  if(code){
    return "yes";
  }else{
    return "no";
  }
};

Blockly.JavaScript['step3'] = function(block) {
  var value_name = Blockly.JavaScript.valueToCode(block, 'name', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action= Blockly.JavaScript.statementToCode(block, 'action').trim();
  var value_then = Blockly.JavaScript.valueToCode(block, 'then', Blockly.JavaScript.ORDER_ATOMIC).trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_name == "(#tadpole_withlegs)" && 
  statements_action == "#eat(#food_plankton)"  && value_then == "(#young_frog)");;
  console.log("step3,code:",code);
  console.log("value_name:",value_name);
  console.log("statements_action:", statements_action);
  console.log("value_then:",value_then);

  if(code){
    return "yes";
  }else{
    return "no";
  }
};

Blockly.JavaScript['step4'] = function(block) {
  var value_name = Blockly.JavaScript.valueToCode(block, 'name', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action= Blockly.JavaScript.statementToCode(block, 'action').trim();
  var value_then = Blockly.JavaScript.valueToCode(block, 'then', Blockly.JavaScript.ORDER_ATOMIC).trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_name == "(#young_frog)" && 
  statements_action == "#leaveWater"  && value_then == "(#frog)");
  console.log("step4,code:",code);
  console.log("value_name:",value_name);
  console.log("statements_action:", statements_action);
  console.log("value_then:",value_then);

  if(code){
    return "yes";
  }else{
    return "no";
  }
};

Blockly.JavaScript['stepall'] = function(block) {
  var value_name1 = Blockly.JavaScript.valueToCode(block, 'name1', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action1 = Blockly.JavaScript.statementToCode(block, 'action1').trim();
  var value_last_1 = Blockly.JavaScript.valueToCode(block, 'last 1', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action2 = Blockly.JavaScript.statementToCode(block, 'action2').trim();
  var value_last_2 = Blockly.JavaScript.valueToCode(block, 'last 2', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action3 = Blockly.JavaScript.statementToCode(block, 'action3').trim();
  var value_last_3 = Blockly.JavaScript.valueToCode(block, 'last 3', Blockly.JavaScript.ORDER_ATOMIC).trim();
  var statements_action4 = Blockly.JavaScript.statementToCode(block, 'action4').trim();
  var value_last_4 = Blockly.JavaScript.valueToCode(block, 'last 4', Blockly.JavaScript.ORDER_ATOMIC).trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_name1 == "(#frog_eggs)" && 
  (statements_action1 == "#water#apporateTemperature" || statements_action1 == "#apporateTemperature#water")
  && value_last_1 == "(#tadpole)" && statements_action2 == "#eat(#food_plankton)"  && value_last_2 == "(#tadpole_withlegs)"
  && statements_action3 == "#eat(#food_plankton)"  && value_last_3 == "(#young_frog)" &&
  statements_action4 == "#leaveWater"  && value_last_4 == "(#frog)");
  console.log("code",code);
  console.log("value_name1",value_name1);
  console.log("value_last_1 ",value_last_1 );
  console.log("value_last_2",value_last_2);
  console.log("value_last_3 ",value_last_3 );
  console.log("value_last_4 ",value_last_4 );
  

  if(code){
    return "yes";
  }else{
    return "no";
  }
};



Blockly.JavaScript['frog_eggs'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#frog_eggs';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['tadpole'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#tadpole';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['tadpole_withlegs'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#tadpole_withlegs';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['young_frog'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#young_frog';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['frog'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#frog';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['food_sunshine'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#foodSushine';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['temperature'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#apporateTemperature';
  return code;
};





Blockly.JavaScript['leaveWater'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#leaveWater';
  return code;
};

Blockly.JavaScript['food_plankton'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#food_plankton';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['eat'] = function(block) {
  var value_question_img = Blockly.JavaScript.valueToCode(block, 'question_img', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = '#eat'+value_question_img;
  return code;
};

Blockly.JavaScript['water'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#water';
  return code;
};

// Blockly.JavaScript['food_temperature'] = function(block) {
//   // TODO: Assemble JavaScript into code variable.
//   var code = '';
//   // TODO: Change ORDER_NONE to the correct strength.
//   return [code, Blockly.JavaScript.ORDER_NONE];
// };

Blockly.JavaScript['sunshine'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#sushine';
  return code;
};