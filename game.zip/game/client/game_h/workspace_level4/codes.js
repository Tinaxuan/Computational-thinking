Blockly.JavaScript['turn'] = function (block) {
  var code = '#'+this.getFieldValue('turn')
  return code;
};