
Blockly.Blocks['turn'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("trun")
        .appendField(new Blockly.FieldDropdown([["select","left"], ["left","left"], ["right","right"]]), "turn");
    this.setInputsInline(false);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};