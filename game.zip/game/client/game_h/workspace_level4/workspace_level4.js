
var score  = 0;
var username;

var demoWorkspace4 = Blockly.inject('gamelevel4',
  {
    media: 'https://unpkg.com/blockly/media/',
    toolbox: document.getElementById('toolboxh_4'),
    zoom: {
      controls : true, 
      wheel : true, 
      startScale : 1, 
      maxScale : 3, 
      minScale : 0.3, 
      scaleSpeed : 1.2
    }
  });
Blockly.Xml.domToWorkspace(document.getElementById('gamelevel4'),
  demoWorkspace4);


document.getElementById("level4").onclick = function () {
  showLevel(4);
  // modal4.style.display = "block";
}

//popup screen
//tip screen
var modal4 = document.getElementById("Tipmodel4");


// get button
var modalBtn4= document.getElementById("tip4");

// button to close
var closeBtn4 =  document.getElementsByClassName("closeBtn4")[0];

var footer = document.getElementsByClassName("modal-footer4")[0];

footer.addEventListener("click",closeModal);

modalBtn4.addEventListener("click",openModal);

closeBtn4.addEventListener("click",closeModal);

window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal4.style.display = "block";
}

// close screen
function closeModal () {
	modal4.style.display = "none";

}

// outsideClick
function outsideClick (e) {
	if(e.target == modal4){
		modal4.style.display = "none";

	}
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal4 = document.getElementById("passTipmodel4");
// button to close
var passcloseBtn4 =  document.getElementsByClassName("passcloseBtn4")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes4 = getDOM("passYes4");
var passNo4 = getDOM("passNo4");

passYes4.addEventListener("click", openNextLevel4);
passNo4.addEventListener("click", stayThisLevel4);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn4.addEventListener("click",closePassModal4);

window.addEventListener("click",passOutsideClick4);


//open next level
function openNextLevel4(){
  closePassModal4();
  showLevel(5);
  
}

//stay this level
function stayThisLevel4(){
  closePassModal4();
  showLevel(4);
  
}
// popup screen
function openPassModal4 () {
	passmodal4.style.display = "block";	
}

// close screen
function closePassModal4 () {
	passmodal4.style.display = "none";
}

// outsideClick
function passOutsideClick4 (e) {
	if(e.target == passmodal4){
		passmodal4.style.display = "none";
	}
}
//~~~~~~~~~~~~````






//get the number of blocks
function getBlocks(code) {
  return getStrCount(code,'#')
}


function getStrCount(scrstr, armstr) { 
  var count = 0;
  while (scrstr.indexOf(armstr) != -1) {
    scrstr = scrstr.replace(armstr, "")
    count++;
  }
  return count;
}

//right--- -90 left :90
function getTurnDeg(type) {
  return type=='right'?(-90):90
}

function getNowDeg(id) {
  var nowtransform = getDOM(id).style.transform;
  var nowDeg = 0;
  if (nowtransform.indexOf('rotate(') > -1) {
    nowDeg = parseInt(nowtransform.split('rotate(')[1].split('deg)')[0])
  }
  return nowDeg
}
function turnElement(id, deg) {
  var nowDeg = getNowDeg(id);
  nowDeg += deg
  if (nowDeg<0){
    nowDeg += 360
  }else if(nowDeg > 360){
    nowDeg -= 360
  }
  getDOM(id).style.transform = getDOM(id).style.transform.split('rotate(')[0]+'rotate(' + nowDeg + 'deg)';
}


function failed(timers=[],message) {
  timers.forEach(timer => {
    clearTimeout(timer)
  })
  alert(message)
}
function getDirection(id,deg) {
  var Direction = ['right', 'top', 'left','bottom'];
  return Direction[getNowDeg(id) % 360 / 90]
}
function level4_move_forward(id,move_length, direction, timers) {
  if (direction == 'left' || direction == 'top'){
    move_length = -move_length
  }
  if (direction == 'bottom' || direction == 'top'){
    var nowPosition = getDOM(id).offsetTop + move_length
    if (nowPosition < 0 || nowPosition > 420) {
      failed(timers, 'Move too much！');
      return
    }
    getDOM(id).style.top = getDOM(id).offsetTop + move_length + 'px'
    

  }
  if (direction == 'left' || direction == 'right'){
    var nowPosition = getDOM(id).offsetLeft + move_length
    if (nowPosition < 0 || nowPosition > 420) {
      failed(timers, 'Move too much！');
      return
    }
    getDOM(id).style.left = getDOM(id).offsetLeft + move_length + 'px'
  }
  // else{
  //   var nowPosition = getDOM(id).offsetLeft + move_length
  //   if (nowPosition < 0 || nowPosition > 420) {
  //     failed(timers, 'Move too much！');
  //     return
  //   }
  //   getDOM(id).style.left = nowPosition + 'px'
  // }
  
  if (getDOM(id).offsetLeft == 420 && getDOM(id).offsetTop == 420){
    setTimeout(() => {
      score = 4;
      update();
      // alert("Congruadation! Rright! \n You can check your score through the leader board.");
      // var r= confirm("Congratulation!You passed the LEVEL 4! \n Go to the Level 5?");
      // if (r==true){
      //   showLevel(5);
      //   }else{
      //     showLevel(4);
      //   }

      openPassModal4();
     

      
    }, 100);
  }
}


function check4() {
  var code = Blockly.JavaScript.workspaceToCode(demoWorkspace4);
  const moves = code.split('#');
  let timers = []
  moves.forEach((move,index) => {
    var timeout = index*100
    let timer = '';
    if (move == 'move_forward') {
      timer = setTimeout(() => {
        level4_move_forward('level4_frog', 60, getDirection('level4_frog'), timers); 
      }, timeout); 
      
    } else if (move == 'left'){
      timer = setTimeout(() => {
        turnElement('level4_frog', getTurnDeg('left'))
      }, timeout); 
    } else if (move == 'right'){
      timer = setTimeout(() => {
        turnElement('level4_frog', getTurnDeg('right'))
      }, timeout);
    }
    timer && timers.push(timer)

  });
  let checkResultTimer = setTimeout(() => {
    var nowTop = getDOM('level4_frog').offsetTop
    var nowLeft = getDOM('level4_frog').offsetLeft 
    console.log("now top",nowTop);
    console.log("now left",nowLeft);
    // if (nowTop != 420 && nowLeft != 420){
    if (nowTop < 420 || nowLeft < 420){
      failed(timers, "KEEP MOVING TO DESTINATION！")
    }
  }, moves.length * 100); 
  timers.push(checkResultTimer)

  

  getDOM("level4_run").innerHTML = 'reset'
  getDOM("level4_run").onclick = function () {

    getDOM("level4_run").onclick = check4 
    getDOM('level4_frog').style.left = 0 + 'px';
    getDOM('level4_frog').style.top = 0 + 'px';
    getDOM("level4_run").innerHTML = 'run';
    getDOM('level4_frog').style.transform = getDOM('level4_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
  }

}

getDOM("level4_run").onclick = check4



async function update() {
  let response = await updateGame_h(username, score);
  return response;
}

window.onload = function() {
  fetch('/user/current')
  .then(res => res.json())
  .then(jsn => {
  console.log("current user", jsn)
  username = jsn.session.user.name;
  console.log("level3_username:",username);
  })
}