Blockly.Blocks['answer_img_cat'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level1/media/cat.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_img_dog'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level1/media/dog.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_statement1_tail'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("tail");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_statement1_tail2'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("tail");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_statement2_feather'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("feather");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['question_1_dog'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("dog");
    this.appendValueInput("question_img")
        .setCheck(null)
        .appendField("                      image:");
    this.appendDummyInput()
        .appendField("legs")
        .appendField(new Blockly.FieldDropdown([["select","4"], ["0","0"], ["2","2"], ["4","5"], ["6","6"]]), "NAME");
    this.appendStatementInput("question_statement")
        .setCheck(null)
        .appendField("features: ");
    this.appendStatementInput("question_statement2")
        .setCheck(null)
        .appendField("specialty：");
    this.appendStatementInput("question_statement3")
        .setCheck(null)
        .appendField("mammal?");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['question_2_cat'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("cat");
    this.appendValueInput("question_img")
        .setCheck(null)
        .appendField("                      image:");
    this.appendDummyInput()
        .appendField("legs")
        .appendField(new Blockly.FieldDropdown([["select","4"], ["0","0"], ["2","2"], ["4","5"], ["6","6"]]), "NAME");
    this.appendStatementInput("question_statement")
        .setCheck(null)
        .appendField("features: ");
    this.appendStatementInput("question_statement2")
        .setCheck(null)
        .appendField("specialty：");
    this.appendStatementInput("question_statement3")
        .setCheck(null)
        .appendField("mammal?");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_img_duck'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("./game_h/workspace_level1/media/duck.jpg", 150, 150, { alt: "*", flipRtl: "FALSE" }));
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['question_3_duck'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("duck");
    this.appendValueInput("question_img")
        .setCheck(null)
        .appendField("                      image:");
    this.appendDummyInput()
        .appendField("legs")
        .appendField(new Blockly.FieldDropdown([["select","4"], ["0","0"], ["2","2"], ["4","5"], ["6","6"]]), "NAME");
    this.appendStatementInput("question_statement")
        .setCheck(null)
        .appendField("features: ");
    this.appendStatementInput("question_statement2")
        .setCheck(null)
        .appendField("specialty：");
    this.appendStatementInput("question_statement3")
        .setCheck(null)
        .appendField("mammal?");
    this.setInputsInline(false);
    this.setColour(90);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_statement3_whiskers'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("whiskers");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['answer_statement3_whiskers2'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("whiskers");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['specialty_fly'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("fly");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['specialty_swim'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("swim");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['specialty_swim2'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("swim");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['specialty_climb'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("climb a tree");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['boolean_yes'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("yes");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['boolean_yes2'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("yes");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['boolean_no'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("no");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(300);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};