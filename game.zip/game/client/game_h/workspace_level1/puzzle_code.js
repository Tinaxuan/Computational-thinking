
Blockly.JavaScript['question_1_dog'] = function(block) {
  var value_question_img = Blockly.JavaScript.valueToCode(block, 'question_img', Blockly.JavaScript.ORDER_ATOMIC);
  var dropdown_name = block.getFieldValue('NAME');
  var statements_question_statement = Blockly.JavaScript.statementToCode(block, 'question_statement').trim();
  var statements_question_statement2 = Blockly.JavaScript.statementToCode(block, 'question_statement2').trim();
  var statements_question_statement3 = Blockly.JavaScript.statementToCode(block, 'question_statement3').trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_question_img=="(#dog)"  && dropdown_name == "5"  &&(statements_question_statement == '#tail#whiskers' || statements_question_statement == '#whiskers#tail') 
    && statements_question_statement2 == '#swim' && statements_question_statement3 == "#yes");

  // statements_question_statement2 == 11 && statements_question_statement3 === 999);
  //&& statements_question_statement3.match('yes')
   //&& (statements_question_statement.match('tail') && statements_question_statement.match('whiskers'))
   
   console.log("value: " , value_question_img);
   console.log(code);
   console.log("dog dropdown:" , dropdown_name);
   console.log("dog statement:" , statements_question_statement);
   console.log("dog statement2:" , statements_question_statement2);
   console.log("dog statement3:" , statements_question_statement3);

  if(code){
      return "yes";
  }else{
      return "no";
  };
  
};


//cat 
Blockly.JavaScript['question_2_cat'] = function(block) {
  var value_question_img = Blockly.JavaScript.valueToCode(block, 'question_img', Blockly.JavaScript.ORDER_ATOMIC);
  var dropdown_name = block.getFieldValue('NAME');
  var statements_question_statement = Blockly.JavaScript.statementToCode(block, 'question_statement').trim();
  var statements_question_statement2 = Blockly.JavaScript.statementToCode(block, 'question_statement2').trim();
  var statements_question_statement3 = Blockly.JavaScript.statementToCode(block, 'question_statement3').trim();
  // TODO: Assemble JavaScript into code variable.
  var code =  (value_question_img=="(#cat)"  && dropdown_name == "5"&&(statements_question_statement ==  '#tail#whiskers' || statements_question_statement == '#whiskers#tail')
    &&statements_question_statement2 == "#climb" && statements_question_statement3 == "#yes");
   //console.log(code);

   console.log("value: " , value_question_img);
   console.log(code);
   console.log("cat dropdown: " , dropdown_name);
   console.log("cat statement: " ,statements_question_statement);
   console.log("cat statement2: " ,statements_question_statement2);
   console.log("cat statement3: " , statements_question_statement3);

   if(code){
    return "yes";
  }else{
    return "no";
  };
};

Blockly.JavaScript['question_3_duck'] = function(block) {
  var value_question_img = Blockly.JavaScript.valueToCode(block, 'question_img', Blockly.JavaScript.ORDER_ATOMIC);
  var dropdown_name = block.getFieldValue('NAME');
  var statements_question_statement = Blockly.JavaScript.statementToCode(block, 'question_statement').trim();
  var statements_question_statement2 = Blockly.JavaScript.statementToCode(block, 'question_statement2').trim();
  var statements_question_statement3 = Blockly.JavaScript.statementToCode(block, 'question_statement3').trim();
  // TODO: Assemble JavaScript into code variable.
  var code = (value_question_img=="(#duck)"  && dropdown_name == '2'
  && statements_question_statement ==  '#feather' && 
  (statements_question_statement2 == '#swim#fly' || statements_question_statement2 == '#fly#swim' )
  && statements_question_statement3 == '#no');
  if(code){
    return "yes";
  }else{
    return "no";
  };
};

Blockly.JavaScript['answer_img_cat'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#cat';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['answer_img_dog'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#dog';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

//tail
Blockly.JavaScript['answer_statement1_tail'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#tail';
  return code;
};

Blockly.JavaScript['answer_statement1_tail2'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#tail';
  return code;
};

//feather
Blockly.JavaScript['answer_statement2_feather'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  code = '#feather';
  return code;
};

Blockly.JavaScript['answer_img_duck'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#duck';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};



//whiskers
Blockly.JavaScript['answer_statement3_whiskers'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#whiskers';
  return code;
};

Blockly.JavaScript['answer_statement3_whiskers2'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '#whiskers';
  return code;
};

Blockly.JavaScript['specialty_fly'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#fly';
  return code;
};

Blockly.JavaScript['specialty_swim'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#swim';
  return code;
};

Blockly.JavaScript['specialty_swim2'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#swim';
  return code;
};

Blockly.JavaScript['specialty_climb'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#climb';
  return code;
};

Blockly.JavaScript['boolean_yes'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#yes';
  return code;
};

Blockly.JavaScript['boolean_yes2'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#yes';
  return code;
};

Blockly.JavaScript['boolean_no'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#no';
  return code;
};