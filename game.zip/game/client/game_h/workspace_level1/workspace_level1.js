var workspace;
var workspaceBlocks;

function getDOM(id) {
	return document.getElementById(id)
}



function showLevel(level) {
	  const levels = [1, 2, 3, 4, 5, 6];
	  levels.forEach(item => {
	    if (level == item && getDOM('gamelevelshow' + item)) {
	      getDOM('gamelevelshow' + item).style.visibility = "visible";
		  getDOM("Tipmodel"+item).style.display = "block";


	    } else {
	      if (getDOM('gamelevelshow' + item)) {
	        getDOM('gamelevelshow' + item).style.visibility = "hidden";
	      }
	    }
	  })
}


var options1 = { 
	toolbox : false, 
	collapse : false, 
	comments : false, 
	disable : false, 
	maxBlocks : Infinity, 
	trashcan : false, 
	horizontalLayout : false, 
	toolboxPosition : 'end', 
	css : true, 
	media : 'https://blockly-demo.appspot.com/static/media/', 
	rtl : false, 
	scrollbars : false, 
	sounds : true, 
	oneBasedIndex : true,
};

var toolbox2 = document.getElementById("toolboxh_2");
var options2 = { 
	toolbox : toolbox2, 
	collapse : false, 
	comments : false, 
	disable : false, 
	maxBlocks : Infinity, 
	trashcan : false, 
	horizontalLayout : false, 
	toolboxPosition : false, 
	css : true, 
	media : 'https://blockly-demo.appspot.com/static/media/', 
	rtl : false, 
	scrollbars : false, 
	sounds : true, 
	oneBasedIndex : true
};


var score  = 0;
var username;

//level 1
/* Inject your workspace */ 
 workspace = Blockly.inject('gamelevel1', options1);

/* TODO: Change workspace blocks XML ID if necessary. Can export workspace blocks XML from Workspace Factory. */
workspaceBlocks = document.getElementById("workspaceBlocksh_1"); 

/* Load blocks to workspace. */
Blockly.Xml.domToWorkspace(workspaceBlocks, workspace);


//click event

function button_click(){
    var code = Blockly.JavaScript.workspaceToCode(workspace);
    if(code.match("no")== null){
		score = 1;
		update();
		// var r= confirm("Congratulation!You passed the LEVEL 1! \n Go to the Level 2?");
		// if (r==true){
		// 	showLevel(2);
		//   }else{
		// 	showLevel(1);
		//   }
		openPassModal1();
    }else{
        alert("Try Again! ");
    }
}

document.getElementById("check_button1").addEventListener("click", button_click);

document.getElementById("back1").addEventListener("click", button_click_back);

function button_click_back(){
	window.location = "index.html";
	// window.location = "home.html";
}


//level clicked
document.getElementById("level1").onclick = function(){
	showLevel(1)
	// modal1.style.display = "block";
}

//tip screen
var modal1 = document.getElementById("Tipmodel1");

// get button
var modalBtn1 = document.getElementById("tip1");

// button to close
var closeBtn1 = document.getElementsByClassName("closeBtn1")[0];

//footer to close
var footer1 = document.getElementsByClassName("modal-footer1")[0];

footer1.addEventListener("click",closeModal);


modalBtn1.addEventListener("click",openModal);

closeBtn1.addEventListener("click",closeModal);



window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal1.style.display = "block";
}

// close screen
function closeModal () {
	modal1.style.display = "none";
}

// outsideClick
function outsideClick (e) {
	if(e.target == modal1){
		modal1.style.display = "none";
	}
}




// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal1 = document.getElementById("passTipmodel1");
// button to close
var passcloseBtn1 =  document.getElementsByClassName("passcloseBtn1")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes1 = getDOM("passYes1");
var passNo1 = getDOM("passNo1");

passYes1.addEventListener("click", openNextLevel1);
passNo1.addEventListener("click", stayThisLevel1);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn1.addEventListener("click",closePassModal1);

window.addEventListener("click",passOutsideClick1);


//open next level
function openNextLevel1(){
  closePassModal1();
  showLevel(2);
  
}

//stay this level
function stayThisLevel1(){
  closePassModal1();
  showLevel(1);
  
}
// popup screen
function openPassModal1 () {
	passmodal1.style.display = "block";	
}

// close screen
function closePassModal1 () {
	passmodal1.style.display = "none";
}

// outsideClick
function passOutsideClick1 (e) {
	if(e.target == passmodal1){
		passmodal1.style.display = "none";
	}
}

async function update() {
	let response = await updateGame_h(username, score);
	return response;
  }
  
  window.onload = function() {
	fetch('/user/current')
	.then(res => res.json())
	.then(jsn => {
	console.log("current user", jsn)
	username = jsn.session.user.name;
	console.log("level1/2_username:",username);
	})
  }


