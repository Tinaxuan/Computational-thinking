var demoWorkspace5 = Blockly.inject('gamelevel5',
  {
    media: 'https://unpkg.com/blockly/media/',
    toolbox: document.getElementById('toolboxh_5'),
    zoom: {
      controls : true, 
      wheel : true, 
      startScale : 1, 
      maxScale : 3, 
      minScale : 0.3, 
      scaleSpeed : 1.2
    }
  });
Blockly.Xml.domToWorkspace(document.getElementById('gamelevel5'),
  demoWorkspace5);

document.getElementById("level5").onclick = function () {
  showLevel(5)
  // modal5.style.display = "block";
}


//popup screen
//tip screen
var modal5 = document.getElementById("Tipmodel5");


// get button
var modalBtn5= document.getElementById("tip5");

// button to close
var closeBtn5 =  document.getElementsByClassName("closeBtn5")[0];

var footer = document.getElementsByClassName("modal-footer5")[0];

footer.addEventListener("click",closeModal);

modalBtn5.addEventListener("click",openModal);

closeBtn5.addEventListener("click",closeModal);

window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal5.style.display = "block";

	
}

// close screen
function closeModal () {
	modal5.style.display = "none";

}

// outsideClick
function outsideClick (e) {
	if(e.target == modal5){
		modal5.style.display = "none";

	}
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal5 = document.getElementById("passTipmodel5");
// button to close
var passcloseBtn5 =  document.getElementsByClassName("passcloseBtn5")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes5 = getDOM("passYes5");
var passNo5 = getDOM("passNo5");

passYes5.addEventListener("click", openNextLevel5);
passNo5.addEventListener("click", stayThisLevel5);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn5.addEventListener("click",closePassModal5);

window.addEventListener("click",passOutsideClick5);


//open next level
function openNextLevel5(){
  closePassModal5();
  showLevel(6);
  
}

//stay this level
function stayThisLevel5(){
  closePassModal5();
  showLevel(5);
  
}
// popup screen
function openPassModal5 () {
	passmodal5.style.display = "block";	
}

// close screen
function closePassModal5 () {
	passmodal5.style.display = "none";
}

// outsideClick
function passOutsideClick5 (e) {
	if(e.target == passmodal5){
		passmodal5.style.display = "none";
	}
}









var timer_level5 = []


function level5_move_forward(id,move_length, direction, timers) {
  if (direction == 'left' || direction == 'top'){
    move_length = -move_length
  }
  if (direction == 'bottom' || direction == 'top'){
    var nowPosition = getDOM(id).offsetTop + move_length
    if (nowPosition < 0 || nowPosition > 420) {
      failed(timers, 'Move too much！');
      return
    }
    getDOM(id).style.top = getDOM(id).offsetTop + move_length + 'px'
  }else{
    var nowPosition = getDOM(id).offsetLeft + move_length
    if (nowPosition < 0 || nowPosition > 420) {
      failed(timers, 'Move too much！');
      return
    }
    getDOM(id).style.left = nowPosition + 'px'
  }
  
  if (getDOM(id).offsetLeft == 420 && getDOM(id).offsetTop == 420){
    setTimeout(() => {
      score = 5;
      update();
      // alert("Congruadation! Rright! \n You can check your score through the leader board.");
      // var r= confirm("Congratulation!You passed the LEVEL 5! \n Go to the Level 6?");
			// if (r==true){
			// 	showLevel(6);
			//   }else{
      //     showLevel(5);
      //   }
      openPassModal5();
    }, 100);
  }
  

}

function analysisCode(code) {
  code.forEach((move,index) => {
    var timeout = timer_level5.length * 100
    let timer = '';
    if (move == 'move_forward') {
      timer = setTimeout(() => {
        level5_move_forward('level5_frog', 60, getDirection('level5_frog'), timer_level5);
      }, timeout);
    } else if (move == 'left') {
      timer = setTimeout(() => {
        turnElement('level5_frog', getTurnDeg('left'))
      }, timeout);
    } else if (move == 'right') {
      timer = setTimeout(() => {
        turnElement('level5_frog', getTurnDeg('right'))
      }, timeout);
    }
    timer_level5.push(timer)
  });
  
}



//code = 'loopStart' + 'timeStart' + code + 'timeEnd' + statements_1 + 'loopEnd';
function check5() {
  var code = Blockly.JavaScript.workspaceToCode(demoWorkspace5);
  var moves = code.split('loopStart');
  var moves2 = []
  moves.forEach(item=>{

    if(item && item.indexOf('loopEnd')>-1){
      moves2 = moves2.concat(item.split('loopEnd'))
    }else{
      moves2 = moves2.concat(item)
    }
  })
  //moves2 : 'timeStart' + code + 'timeEnd' + statements_1
  //statements_1: #move
  moves2.forEach(item=>{
    if(item.indexOf('timeStart')>-1){
      const times = item.split('timeStart')[1].split('timeEnd')[0];
      for (let i = 0; i < times;i++){
        analysisCode((item.split('timeEnd')[1] || '').split('#'))
      }
    }else{
      analysisCode(item.split('#'))
    }
  })

  
  let checkResultTimer = setTimeout(() => {
    var nowTop = getDOM('level5_frog').offsetTop
    var nowLeft = getDOM('level5_frog').offsetLeft
    if (nowTop < 420 || nowLeft < 420) {
      failed(timer_level5, 'Keep going！')
    }
  }, timer_level5.length * 100);
  timer_level5.push(checkResultTimer)
  console.log(code);
  console.log(moves2);
  // test(code);
  getDOM("level5_run").innerHTML = 'reset'
  getDOM("level5_run").onclick = function () {
    getDOM("level5_run").onclick = check5;
    getDOM('level5_frog').style.left = 0 + 'px';
    getDOM('level5_frog').style.top = 0 + 'px';
    getDOM("level5_run").innerHTML = 'run';
    getDOM('level5_frog').style.transform = getDOM('level5_frog').style.transform.split('rotate(')[0] + 'rotate(' + 0 + 'deg)';
    timer_level5 = []
  }
  return;
}

getDOM("level5_run").onclick = check5


async function update() {
  let response = await updateGame_h(username, score);
  return response;
}

window.onload = function() {
  fetch('/user/current')
  .then(res => res.json())
  .then(jsn => {
  console.log("current user", jsn)
  username = jsn.session.user.name;
  console.log("level5_username:",username);
  })
}