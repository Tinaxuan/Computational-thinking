
Blockly.Blocks['repeat'] = {
  init: function() {
    this.appendStatementInput("loop")
        .setCheck(null)
        .appendField("repeat");
    this.appendDummyInput()
        .appendField(new Blockly.FieldNumber(0), "times")
        .appendField("times");
    this.setInputsInline(false);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(270);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};