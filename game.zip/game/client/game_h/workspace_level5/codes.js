Blockly.JavaScript['repeat'] = function (block) {
  var code = this.getFieldValue('times')
  var id = new Date().getTime()
  var statements_1 = Blockly.JavaScript.statementToCode(block, 'loop');
  return 'loopStart' + 'timeStart' + code + 'timeEnd' + statements_1 + 'loopEnd';
};