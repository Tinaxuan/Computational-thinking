Blockly.JavaScript['move_forward'] = function (block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '';
  code = '#move_forward';
  return code;
};