
var toolbox3 =getDOM("toolboxh_3");

var score  = 0;
var username;


//var demoWorkspace = Blockly.inject('gamelevel3', options3);
var demoWorkspace = Blockly.inject('gamelevel3',
  {
    media: 'https://unpkg.com/blockly/media/',
    toolbox: document.getElementById('toolboxh_3'),
    
    zoom: {
      controls : true, 
      wheel : true, 
      startScale : 1, 
      maxScale : 3, 
      minScale : 0.3, 
      scaleSpeed : 1.2
    }
  });
 Blockly.Xml.domToWorkspace(document.getElementById('gamelevel3'),
  demoWorkspace);


  document.getElementById("level3").onclick = function () {
    showLevel(3);
    // modal3.style.display = "block";
  }

  //instruction when users try to move the frog
  document.getElementById("level3_frog").onmousedown = function(){
    modal3.style.display ="block";
  }


//popup screen
//tip screen
var modal3 = document.getElementById("Tipmodel3");


// get tip button
var modalBtn3= document.getElementById("tip3");

// button to close
var closeBtn3 =  document.getElementsByClassName("closeBtn3")[0];


//footer to close
var footer = document.getElementsByClassName("modal-footer3")[0];

footer.addEventListener("click",closeModal);


modalBtn3.addEventListener("click",openModal);

closeBtn3.addEventListener("click",closeModal);

window.addEventListener("click",outsideClick);

// popup screen
function openModal () {
	modal3.style.display = "block";	
}

// close screen
function closeModal () {
	modal3.style.display = "none";
}

// outsideClick
function outsideClick (e) {
	if(e.target == modal3){
		modal3.style.display = "none";
	}
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//pass screen
var passmodal = document.getElementById("passTipmodel3");
// button to close
var passcloseBtn =  document.getElementsByClassName("passcloseBtn3")[0];
//footer to close
// var passfooter3 = document.getElementsByClassName("passmodal-footer3")[0];
//Yes No to pass
var passYes = getDOM("passYes3");
var passNo = getDOM("passNo3");

passYes.addEventListener("click", openNextLevel);
passNo.addEventListener("click", stayThisLevel);

//passfooter3.addEventListener("click",closePassModal3);

passcloseBtn.addEventListener("click",closePassModal);

window.addEventListener("click",passOutsideClick);


//open next level
function openNextLevel(){
  closePassModal();
  showLevel(4);
  
}

//stay this level
function stayThisLevel(){
  closePassModal();
  showLevel(3);
  
}
// popup screen
function openPassModal () {
	passmodal.style.display = "block";	
}

// close screen
function closePassModal () {
	passmodal.style.display = "none";
}

// outsideClick
function passOutsideClick (e) {
	if(e.target == passmodal){
		passmodal.style.display = "none";
	}
}





  // # move_forward 
function check() {
  var code = Blockly.JavaScript.workspaceToCode(demoWorkspace);
  const moves = code.split('#');
  let move_length = 0;
  let timer = '';
  moves.forEach((move, index) => {
    var timeout = 100 * index;
    if (move == 'move_forward') {  
        move_length = 60;
        timer = setTimeout(() =>  {
          move_forward(move_length);
        },timeout);       
    }
  });



  //set time out
  // setTimeout(() => {
  //   if (getDOM('level3_frog').offsetLeft == 420) {
  //     score = 3;
  //     update();
  //     var r= confirm("Congratulation!You passed the LEVEL 3! \n Go to the Level 4?");
  //     if (r==true){
  //       showLevel(4);       
  //       }else{
  //       showLevel(3);
  //       }
  //   }else{
  //     score = 0;
  //     alert("Keep going！");
  //     console.log(score);
  //   }
    
  // }, 800);


  setTimeout(() => {
    if (getDOM('level3_frog').offsetLeft == 420) {
      score = 3;
      update();
      openPassModal();
    }else if(getDOM('level3_frog').offsetLeft > 420){
      score = 0;
      alert("Move outside！");
      getDOM('level3_frog').style.left = 420 + 'px';

    }else{
      score = 0;
      alert("KEEP MOVING TO DESTINATION！");
      console.log(score);
    }
    console.log("left:",getDOM('level3_frog').offsetLeft);
    
  }, 800);


  getDOM("level3_run").innerHTML = 'reset'
  getDOM("level3_run").onclick = function () {
    getDOM("level3_run").onclick = check;
    getDOM('level3_frog').style.left = 0 + 'px';
    getDOM("level3_run").innerHTML = 'run';
  }
}




getDOM("level3_run").onclick = check
function move_forward(move_length) {
  if (getDOM('level3_frog').offsetLeft > 420){
    setTimeout(() => {
      alert("Move Outside！");
    }, 200); 
    return
  } else{
    getDOM('level3_frog').style.left = getDOM('level3_frog').offsetLeft + move_length + 'px'
  }
}

//how many blcoks i used 
function getBlocks(code) {
  return getStrCount(code, '#')
}


function getStrCount(scrstr, armstr) { //scrstr:original  armstr:#
  var count = 0;
  while (scrstr.indexOf(armstr) != -1) {
    scrstr = scrstr.replace(armstr, "")
    count++;
  }
  return count;
}


// window.onload = function() {
//   fetch('/user/current')
//   .then(res => res.json())
//   .then(jsn => console.log("current user LEVEL3", jsn.user.name));
// }

async function update() {
  let response = await updateGame_h(username, score);
  return response;
}

window.onload = function() {
  fetch('/user/current')
  .then(res => res.json())
  .then(jsn => {
  console.log("current user", jsn)
  username = jsn.session.user.name;
  console.log("level3_username:",username);
  })
}

