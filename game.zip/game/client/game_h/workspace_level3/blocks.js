Blockly.Blocks['move_forward'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("move forward one step");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setInputsInline(false);
  }
};