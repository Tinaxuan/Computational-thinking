var usedBlocks = new Object();

Blockly.Blocks['back_to_till'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("Back to till");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['waiter_back_to_till'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("Back to till");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(200);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['one_steps_to_right'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to right");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['one_steps_to_left'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to left");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['one_steps_to_up'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to up");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['one_steps_to_down'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to down");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['transfer'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("pick up 1 meat from tranfer table");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['waiter_transfer'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("put down 1 meat to tranfer table");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(100);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};


Blockly.Blocks['pick_up_drink'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("pick up drink")
            .appendField(new Blockly.FieldDropdown([["coffee", "coffee"], ["tea", "tea"], ["hot_chocolate", "hot_chocolate"]]), "pick up drink");
        this.setInputsInline(false);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};


Blockly.Blocks['pick_up_food'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("pick up food")
            .appendField(new Blockly.FieldDropdown([["cake", "cake"], ["salads", "salads"], ["sandwich", "sandwich"], ["meat", "meat"]]), "pick up food");
        this.setInputsInline(false);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['food_stock'] = {
    init: function () {
        this.appendDummyInput()
            .appendField(new Blockly.FieldDropdown([["cakeStock", "cakeStock"], ["saladStock", "saladStock"], ["sandwichStock", "sandwichStock"],  ["transferStock", "transferStock"]]), "food_stock");
        this.setOutput(true, "Number");
        this.setColour(180);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};



Blockly.JavaScript['back_to_till'] = function (block) {
    var code = 'backToTill(); \n';
    return code;
}

Blockly.JavaScript['waiter_back_to_till'] = function (block) {
    var code = 'waiter_backToTill(); \n';
    return code;
}

Blockly.JavaScript['one_steps_to_right'] = function (block) {
    var code = 'moveright(); \n';
    return code;
}

Blockly.JavaScript['one_steps_to_left'] = function (block) {
    var code = 'moveleft(); \n';
    return code;
}

Blockly.JavaScript['one_steps_to_up'] = function (block) {
    var code = 'moveup(); \n';
    return code;
}

Blockly.JavaScript['one_steps_to_down'] = function (block) {
    var code = 'movedown(); \n';
    return code;
}

Blockly.JavaScript['pick_up_drink'] = function (block) {
    var dropdown_drink = block.getFieldValue('pick up drink');
    // TODO: Assemble JavaScript into code variable.
    if (dropdown_drink === "coffee") {
        var code = 'pick_up_coffee(); \n';
    }
    if (dropdown_drink === "tea") {
        var code = 'pick_up_tea(); \n';
    }
    if (dropdown_drink === "hot_chocolate") {
        var code = 'pick_up_hot_chocolate(); \n';
    }
    return code;
};

Blockly.JavaScript['pick_up_food'] = function (block) {
    var dropdown_food = block.getFieldValue('pick up food');
    // TODO: Assemble JavaScript into code variable.
    if (dropdown_food === "cake") {
        var code = 'pick_up_cake(); \n';
    }
    if (dropdown_food === "salads") {
        var code = 'pick_up_salads(); \n';
    }
    if (dropdown_food === "sandwich") {
        var code = 'pick_up_sandwich(); \n';
    }
    if (dropdown_food === "meat") {
        var code = 'pick_up_meal(); \n';
    }
    return code;
};

Blockly.JavaScript['food_stock'] = function (block) {
    var dropdown_food_stock = block.getFieldValue('food_stock');
    // var value_food_stock = Blockly.JavaScript.valueToCode(block, 'food_stock', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    if (dropdown_food_stock === "cakeStock") {
        var code = 'checkCakeStock()';
    }
    if (dropdown_food_stock === "saladStock") {
        var code = 'checkSaladsStock()';
    }
    if (dropdown_food_stock === "sandwichStock") {
        var code = 'checkSandwichStock()';
    }

    if (dropdown_food_stock === "transferStock") {
        var code = 'checkTransferStock()';
    }
    // TODO: Change ORDER_NONE to the correct strength.
    return [code,Blockly.JavaScript.ORDER_ATOMIC];
};

Blockly.JavaScript['transfer'] = function (block) {
    var code = 'transfer(); \n';
    return code;
}

Blockly.Blocks['waiter_one_steps_to_right'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to right");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(200);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['waiter_one_steps_to_left'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to left");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(200);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['waiter_one_steps_to_up'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to up");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(200);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.Blocks['waiter_one_steps_to_down'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("One steps to down");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(200);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};


Blockly.Blocks['waiter_pick_up_food'] = {
    init: function () {
        this.appendDummyInput()
            .appendField("pick up food")
            .appendField(new Blockly.FieldDropdown([["salads", "salads"], ["meat", "meat"]]), "pick up food");
        this.setInputsInline(false);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(100);
        this.setTooltip("");
        this.setHelpUrl("");
    }
};

Blockly.JavaScript['waiter_one_steps_to_right'] = function (block) {
    var code = 'waiter_moveright(); \n';
    return code;
}

Blockly.JavaScript['waiter_one_steps_to_left'] = function (block) {
    var code = 'waiter_moveleft(); \n';
    return code;
}

Blockly.JavaScript['waiter_one_steps_to_up'] = function (block) {
    var code = 'waiter_moveup(); \n';
    return code;
}

Blockly.JavaScript['waiter_one_steps_to_down'] = function (block) {
    var code = 'waiter_movedown(); \n';
    return code;
}

Blockly.JavaScript['waiter_pick_up_food'] = function (block) {
    var dropdown_food = block.getFieldValue('pick up food');
    // TODO: Assemble JavaScript into code variable.
    if (dropdown_food === "salads") {
        var code = 'waiter_pick_up_salads(); \n';
    }
    if (dropdown_food === "meat") {
        var code = 'waiter_pick_up_meal(); \n';
    }
    return code;
};

Blockly.JavaScript['waiter_transfer'] = function (block) {
    var code = 'waiter_transfer(); \n';
    return code;
}
