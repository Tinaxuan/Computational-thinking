
//import Blockly from 'blockly';
var workspace = Blockly.inject('blocklyDiv',
    {// media: 'https://unpkg.com/blockly/media/',
        toolbox: document.getElementById("toolbox_c"),
        zoom:
         {controls: true,
          wheel: true,
          startScale: 0.8,
          maxScale: 3,
          minScale: 0.3,
          scaleSpeed: 1.2,
          pinch: true},
     trashcan: true
    });

//set up some goloab variables for our interpreter to interact with
//RL: These would be better in window.onload
var outputArea = document.getElementById('output'); //used to output messages to the screen
var stepButton = document.getElementById('stepButton'); //button to step through the code

//set up a variable to store our interpreter
var myInterpreter = null;
var username;

function initApi(interpreter, globalObject) {
    // Add an API function for the alert() block, generated for "text_print" blocks.
    interpreter.setProperty(globalObject, 'alert',
        interpreter.createNativeFunction(function (text) {
            text = arguments.length ? text : '';
            outputArea.value += '\n' + text // uses our output area to 'alert' messages
        }));

    // Add an API function for the prompt() block.
    var wrapper = function (text) {
        return interpreter.createPrimitive(prompt(text));
    };
    interpreter.setProperty(globalObject, 'prompt',
        interpreter.createNativeFunction(wrapper));

    // Add an API function for highlighting blocks.
    wrapper = function (id) {
        id = String(id || '');
        //RL: need to add a try-and-catch because not all blocks can be highlighted
        try { return interpreter.createPrimitive(highlightBlock(id)); }
        catch (e) { console.log("could not create primitive", id); }
    };
    interpreter.setProperty(globalObject, 'highlightBlock',
        interpreter.createNativeFunction(wrapper));

    //RL: Add API functions for our custom blocks
    wrapper = function (id) {
        moveright();
    };
    interpreter.setProperty(globalObject, 'moveright',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        moveleft();
    };
    interpreter.setProperty(globalObject, 'moveleft',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        moveup();
    };
    interpreter.setProperty(globalObject, 'moveup',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        movedown();
    };
    interpreter.setProperty(globalObject, 'movedown',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        pick_up_coffee();
    };
    interpreter.setProperty(globalObject, 'pick_up_coffee',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        pick_up_tea();
    };
    interpreter.setProperty(globalObject, 'pick_up_tea',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        pick_up_hot_chocolate();
    };
    interpreter.setProperty(globalObject, 'pick_up_hot_chocolate',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        pick_up_cake();
    };
    interpreter.setProperty(globalObject, 'pick_up_cake',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            pick_up_sandwich();
    };
    interpreter.setProperty(globalObject, 'pick_up_sandwich',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            pick_up_salads();
    };
    interpreter.setProperty(globalObject, 'pick_up_salads',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            pick_up_meal();
    };
    interpreter.setProperty(globalObject, 'pick_up_meal',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            return checkCakeStock();
    };
    interpreter.setProperty(globalObject, 'checkCakeStock',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            return checkSaladsStock();
    };
    interpreter.setProperty(globalObject, 'checkSaladsStock',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            return checkSandwichStock();
    };
    interpreter.setProperty(globalObject, 'checkSandwichStock',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            return checkTransferStock();
    };
    interpreter.setProperty(globalObject, 'checkTransferStock',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            transfer();
    };
    interpreter.setProperty(globalObject, 'transfer',
    interpreter.createNativeFunction(wrapper));


    wrapper = function (id) {
        waiter_moveright();
    };
    interpreter.setProperty(globalObject, 'waiter_moveright',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        waiter_moveleft();
    };
    interpreter.setProperty(globalObject, 'waiter_moveleft',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        waiter_moveup();
    };
    interpreter.setProperty(globalObject, 'waiter_moveup',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
        waiter_movedown();
    };
    interpreter.setProperty(globalObject, 'waiter_movedown',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            waiter_pick_up_salads();
    };
    interpreter.setProperty(globalObject, 'waiter_pick_up_salads',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            waiter_pick_up_meal();
    };
    interpreter.setProperty(globalObject, 'waiter_pick_up_meal',
        interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            waiter_transfer();
    };
    interpreter.setProperty(globalObject, 'waiter_transfer',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            backToTill();
    };
    interpreter.setProperty(globalObject, 'backToTill',
    interpreter.createNativeFunction(wrapper));

    wrapper = function (id) {
            waiter_backToTill();
    };
    interpreter.setProperty(globalObject, 'waiter_backToTill',
    interpreter.createNativeFunction(wrapper));



}


var highlightPause = false;
var latestCode = '';

function highlightBlock(id) {
    workspace.highlightBlock(id);
    highlightPause = true;

    let type = workspace.getBlockById(id).type;

    if (usedBlocks[type]) {
      usedBlocks[type] = usedBlocks[type] + 1;
    }
    else {
      usedBlocks[type] = 1;
    }
    // console.log(usedBlocks[type]);
    // console.log(type);
}

function resetStepUi(clearOutput) {
    workspace.highlightBlock(null);
    highlightPause = false;
    // if (clearOutput) {
    //     //RL: reset the game level too
    //     try { resetLevel(); } catch (e) { console.log("Too soon. Just ignore me :)") }
    //     outputArea.value = 'Program output:\n=================';
    // }
}

function generateCodeAndLoadIntoInterpreter() {
    // Generate JavaScript code and parse it.
    Blockly.JavaScript.STATEMENT_PREFIX = 'highlightBlock(%1);\n';
    Blockly.JavaScript.addReservedWords('highlightBlock');
    //RL: Infinite loop trap
    window.LoopTrap = 1000;
    Blockly.JavaScript.INFINITE_LOOP_TRAP = 'if(--window.LoopTrap == 0) throw "Infinite loop.";\n';
    latestCode = Blockly.JavaScript.workspaceToCode(workspace);
    resetStepUi(true);
}

function stepCode() {
    if (!myInterpreter) {
        // First statement of this code.
        // Clear the program output.
        resetStepUi(true);
        myInterpreter = new Interpreter(latestCode, initApi);

        // And then show generated code in an alert.
        // In a timeout to allow the outputArea.value to reset first.
        setTimeout(function () {
            alert('Ready to execute the following code\n' +
                '===================================\n' + latestCode);
            highlightPause = true;
            stepCode();
        }, 1);
        return;
    }
    highlightPause = false;
    do {
        try {
            var hasMoreCode = myInterpreter.step();
            if (!inBounds()) {
                alert("You went out of bounds! Try again.");
                hasMoreCode = false;
            }
        } finally {
            if (!hasMoreCode) {
                // Program complete, no more code to execute.
                outputArea.value += '\n\n<< Program complete >>';

                myInterpreter = null;
                resetStepUi(false);

                // Cool down, to discourage accidentally restarting the program.
                stepButton.disabled = 'disabled';
                setTimeout(function () {
                    stepButton.disabled = '';
                }, 2000);

                return;
            }
        }
        // Keep executing until a highlight statement is reached,
        // or the code completes or errors.
    } while (hasMoreCode && !highlightPause);
}

//RL: function to attach as a click handler to a run button
function run_code() {
    //reset the interpreter so we can start execution again next time the button is pressed
    resetStepUi(true);
    myInterpreter = new Interpreter(latestCode, initApi);
    // And then show generated code in an alert.
    // In a timeout to allow the outputArea.value to reset first.
    // alert("Start to run your code");
    alert('Ready to execute the following code\n' +
        '===================================\n' + latestCode);

    function nextStep() {
        if (myInterpreter.step()) {
            //RL: after a step, check if the player is still in bounds


            if (!inBounds()) {
                alert("waiteress went out of bounds! Try again.");
                resetLevel();
              }

            else {
                setTimeout(nextStep, 30);
            }
        }
        else {
            //RL: call the new function the code was moved to
            if (checkWin()) {

              if(gameState == 8){
                console.log("Current gameState:", gameState);
                showPopCongrat();
              }else{
                gameState++;
                alert('Pass, Your score already is recorded to leader board. Welcome to level' + gameState + '!');
              }
              resetLevel();
              update();

            } else {
                alert('Sorry,try again!');
                resetLevel();
            }
        }
    }
    nextStep();
}

// Load the interpreter now, and upon future changes.
//RL: This would be better in window.onload
generateCodeAndLoadIntoInterpreter();
workspace.addChangeListener(function (event) {
    if (!(event instanceof Blockly.Events.Ui)) {
        // Something changed. Parser needs to be reloaded.
        generateCodeAndLoadIntoInterpreter();
    }
});

window.onload = function() {
  fetch('/user/current')
  .then(res => res.json())
  .then(jsn => {
      console.log("current user", jsn)
      username = jsn.session.user.name;
  })
}

async function update() {
  let response = await updateGame_c(username, gameState*2);
  return response;
}
