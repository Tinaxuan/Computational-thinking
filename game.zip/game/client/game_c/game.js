
let character = null;
let person2 = null;
let level = null;
let x = 880;
let y = 500;
let p = 68;
let buttonXPos1 = 700;
let gameState = 1;
let buttonXPos2, buttonXPos3, buttonXPos4, buttonXPos5, buttonXPos6, buttonXPos7, buttonXPos8, buttonXPos9, buttonXPos10;
let getCoffee = 0;
let getCake = 0;
let getSandwich = 0;
let getMeal = 0;
let getSalads = 0;
let getTransfer = 0;

let cakeStock = 20;
let saladsStock = 20;
let sandwichStock = 0;
let transferStock = 0;

let step = 0;
let board = null;

let x_b = 1180;
let y_b = 500;

let toolbox = "toolbox_c";
let legend;

function setup() {
  let width = windowWidth - 600;
  let canvas = createCanvas(width, 800);
  canvas.position(650, 10);

  levelPane = createImg("images_c/levelPane.png");
  levelPane.position(680, 10);

  placeButtons();

  hintPane = createImg("images_c/hintPane1.png");
  hintPane.position(680, 100);

  mainPane = createImg("images_c/mainPane.png");
  mainPane.position(680, 300);

  //create the person and level images
  level = createImg("images_c/level1.png");
  level.position(680, 300);
  character = createImg("images_c/person.png");

  person2 = createImg("images_c/person2null.png");
  legend = createImg("images_c/legend.png");
  legend.position(680, 720);
  // cake = createImg("images/cake1.png");
  //button1.attribute("src", "images/button1Click.png");
  level1(); //added this so the start level works properly.
}

function draw() {
  background(255);
  textSize(20);
  text('cakeStock: ' + cakeStock, 50, 730);

  button1.mousePressed(level1);
  hint1.mousePressed(showPop1);
  button2.mousePressed(level2);
  // hint2.mousePressed(showPop2);
  button3.mousePressed(level3);
  button4.mousePressed(level4);
  hint4.mousePressed(showPop4);
  button5.mousePressed(level5);
  button6.mousePressed(level6);
  hint6.mousePressed(showPop6);
  button7.mousePressed(level7);
  button8.mousePressed(level8);


  if (character != null) {
    character.position(x, y);
  }
  else {
    console.log("There is no person to draw");
  }

  if(gameState == 5 || gameState == 6 || gameState == 7 || gameState == 8 ){
    person2.position(x_b, y_b);
  }
}

//RL: moved from the blockly_interpreter - it is about the game so should be here
function checkWin() {
  let win = false;
  switch (gameState) {
    case 1:
      win = (x == 880 && y == 500 && getCoffee == 1 && step > 1);
      break;
    case 2:
      // win = (x == 780 && y == 500 && getCake == 5 && step > 1 && usedBlocks['controls_repeat_ext'] >= 1);
      win = (x == 880 && y == 500 && getCoffee == 3 && getCake == 3 && usedBlocks['procedures_defnoreturn'] >= 1 && usedBlocks['procedures_callnoreturn'] >=1);
      break;
    case 3:
      win = (x == 880 && y == 500 && getCoffee == 1 && getCake == 1 && getMeal == 1 && step > 1 && usedBlocks['procedures_defnoreturn'] >=1 &&usedBlocks['procedures_callnoreturn'] >=1);
      break;
    case 4:
    win = (x == 880 && y == 500 && getCake == 1 && getMeal == 1 && getSandwich == 0 && step > 1 && usedBlocks['procedures_defnoreturn'] >=2 &&usedBlocks['procedures_callnoreturn'] >= 2 && usedBlocks['controls_if'] >= 1);

      console.log("used if block", usedBlocks['controls_if'], usedBlocks['food_stock'])
      // win = (x == 780 && y == 500 && usedBlocks['controls_if'] >= 1);
      break;
    case 5:
      // win = (x == 780 && y == 500 && getCake == 1 && getSandwich == 0 &&step > 1 && usedBlocks['controls_if'] >= 1);
      win = (x == 880 && y == 500 && x_b == 880 && y_b == 500 && getCake == 1 && getMeal == 1 && getSandwich == 0 && getCoffee ==0 && step > 1 && usedBlocks['procedures_defnoreturn'] >=2 &&usedBlocks['procedures_callnoreturn'] >= 2 && usedBlocks['controls_if'] >= 1);
      console.log("pick up coffee", getCoffee)
      break;
    case 6:
      // win = (getCoffee == 2 && getMeal == 1 && usedBlocks['procedures_defnoreturn'] >= 1 && usedBlocks['procedures_callnoreturn'] == 3);
      win = (x == 880 && y == 500 && getMeal == 1 && getSalads == 1 && transferStock>=1 && getTransfer>=1 && step > 1 && usedBlocks['procedures_defnoreturn'] >= 2 && usedBlocks['procedures_callnoreturn'] >= 2);

      break;
    case 7:
    win = (x == 880 && y == 500 && getSalads == 1 && transferStock ==1 && getTransfer == 1 && step > 1 && usedBlocks['procedures_defnoreturn'] >= 2 && usedBlocks['procedures_callnoreturn'] >= 2 && usedBlocks['controls_if'] >= 1);

      // win = (getCoffee == 1 && getCake == 1 && getSalads == 1 && getMeal == 1 && step > 1 && usedBlocks['procedures_defnoreturn'] >= 1 && usedBlocks['procedures_callnoreturn']>= 1);
      break;
    case 8:
    win = (x == 880 && y == 500 && getCoffee ==1 && getSalads == 2 && getMeal == 3 && transferStock >=3 && getTransfer >=3 && step > 1 && usedBlocks['procedures_defnoreturn'] >= 4 && usedBlocks['procedures_callnoreturn'] >= 4);

      // win = (x == 780 && y == 500 && getCoffee >= 1 && getMeal >= 1 && getSalads>=1 && transferStock>=1 && getTransfer>=1 && step > 1 && usedBlocks['procedures_defnoreturn'] >= 1 && usedBlocks['procedures_callnoreturn'] >= 1);
      break;
    default: console.log("cannot check win for", gameState); break;
  }
  // if (win) {
  //   if(gameState == 8){
  //     resetLevel();
  //   } else{
  //     gameState++;

  //     resetLevel();
  //   }
  //   // update();
  // }
  return win;
}

//RL: reset the game level based on current gameState
function resetLevel() {
  switch (gameState) {
    case 1: level1(); break;
    case 2:
      level2();
      comsole.log("level2");
      break;
    case 3: level3(); break;
    case 4: level4(); break;
    case 5: level5(); break;
    case 6: level6(); break;
    case 7: level7(); break;
    case 8: level8(); break;
    default: console.log("cannot reset to level", gameState); break;
  }
}

function resetGetting(){
  getCoffee = 0;
  getCake = 0;
  getSalads = 0;
  getSandwich = 0;
  getMeal = 0;
  getTransfer = 0;
  transferStock = 0;
}

//RL: uses the board array to check if the person is where they are allowed to be
function inBounds() {
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  //console.log("person at ", row, col, board[row][col], board);
  if (row < 0 || col < 0 || row >= board.length || col >= board[row].length || board[row][col] == 0) {
    return false;
  }
  else {
    return true;
  }
}


function waiter_inBounds() {
  let row = Math.floor((y_b - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x_b - 680) / 100); //need to take the offset for the level off the x
  //console.log("person at ", row, col, board[row][col], board);
  if (row < 0 || col < 0 || row >= board.length || col >= board[row].length || board[row][col] == 0) {
    return false;
  }
  else {
    return true;
  }
}

function resetPosition(){
  x = 880;
  y = 500;

  x_b = 1180;
  y_b = 500;

}

function drinkBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 2) {
    return true;
  }
  else {
    return false;
  }
}



function cakeBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 3) {
    return true;
  }
  else {
    return false;
  }
}


function saladsBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 4) {
    return true;
  }
  else {
    return false;
  }
}

function waiter_saladsBounds(){
  let row = Math.floor((y_b - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x_b - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 4) {
    return true;
  }
  else {
    return false;
  }
}

function sandwichBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 3) {
    return true;
  }
  else {
    return false;
  }
}

function mealBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 5) {
    return true;
  }
  else {
    return false;
  }
}

function waiter_mealBounds(){
  let row = Math.floor((y_b - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x_b - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 5) {
    return true;
  }
  else {
    return false;
  }
}

function transferBounds(){
  let row = Math.floor((y - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 6) {
    return true;
  }
  else {
    return false;
  }
}

function waiter_transferBounds(){
  let row = Math.floor((y_b - 300) / 100); //need to take the offset for the level off the y
  let col = Math.floor((x_b - 680) / 100); //need to take the offset for the level off the x
  if (board[row][col] == 6) {
    return true;
  }
  else {
    return false;
  }
}

//0 means person is not allowed there
//1 means walking place
//2 means can pick up Coffee here
//3 means can pick up cake here
//4 means can pick salads here
//5 means can pick up meal here
//6 means can transfer here


function level1() {
  resetPosition();
  resetGetting();
  gameState = 1;
  cakeStock = 8;
  resetButtons();
  button1.attribute("src", "images_c/button1Click.png");
  person2.attribute("src", "images_c/person2null.png");
  hintPane.attribute("src", "images_c/hintPane1.png");
  level.attribute("src", "images_c/level1.png");
  board = [
    [0, 0, 0, 0],
    [0, 2, 1, 1],
    [0, 3, 1, 1],
    [0, 0, 0, 1]]; //RL: 0 means person is not allowed there
  // toolbox = "toolbox_c1";
  document.getElementById("hint1Pop").style.display="none";
  document.getElementById("hint2Pop").style.display="none";
  document.getElementById("hint4Pop").style.display="none";
  document.getElementById("hint6Pop").style.display="none";
  document.getElementById("congratPop").style.display="none";

}

function level2() {
  // document.getElementById("hint1").style.display = "none";
  // document.getElementById("hint2").style.display = "block";
  resetPosition();
  resetGetting();
  gameState = 2;
  cakeStock = 8;
  resetButtons();
  button2.attribute("src", "images_c/button2Click.png");
  person2.attribute("src", "images_c/person2null.png");
  hintPane.attribute("src", "images_c/hintPane2.png");
  level.attribute("src", "images_c/level2.png");
  board = [
    [0, 0, 0, 0],
    [0, 2, 1, 1],
    [0, 3, 1, 1],
    [0, 0, 0, 1]]; //RL: 0 means person is not allowed there
  // toolbox = "toolbox_c2";
  showPop6();

}

//0 means person is not allowed there
//1 means walking place
//2 means can pick up Coffee here
//3 means can pick up cake here
//4 means can pick salads here
//5 means can pick up meal here
//6 means can transfer here

function level3() {
  gameState = 3;
  cakeStock = 3;
  resetButtons();
  button3.attribute("src", "images_c/button3Click.png");
  person2.attribute("src", "images_c/person2null.png");
  hintPane.attribute("src", "images_c/hintPane3.png");
  level.attribute("src", "images_c/level3.png");
  //RL: these need to be here so when you change level the person is in the right place(!)
  resetPosition()
  //RL: these need to be here so when you change level we do not have coffe and cakes from the last level
  resetGetting();
  board = [
    [0, 0, 0, 0, 0, 1, 0],
    [0, 2, 1, 1, 0, 1, 0],
    [0, 3, 1, 1, 1, 5, 0],
    [0, 0, 0, 1, 1, 1, 0]];
}

function level4() {
  resetPosition();
  resetGetting();
  console.log("Current level is level 4");
  gameState = 4;
  cakeStock = 1;
  resetButtons();
  button4.attribute("src", "images_c/button4Click.png");
  person2.attribute("src", "images_c/person2null.png");
  hintPane.attribute("src", "images_c/hintPane4.png");
  level.attribute("src", "images_c/level4.png");
  //RL: these need to be here so when you change level the person is in the right place(!)
  board = [
    [0, 0, 0, 0, 0, 1, 0],
    [0, 2, 1, 1, 0, 1, 0],
    [0, 3, 1, 1, 1, 5, 0],
    [0, 0, 0, 1, 1, 1, 0]];

    showPop4();
}

function level5() {
  resetPosition();
  resetGetting();
  gameState = 5;
  cakeStock = 1;
  resetButtons();
  button5.attribute("src", "images_c/button5Click.png");
  person2.attribute("src", "images_c/person2.png");
  hintPane.attribute("src", "images_c/hintPane5.png");
  level.attribute("src", "images_c/level5.png");
  //RL: these need to be here so when you change level the person is in the right place(!)

  board = [
    [0, 0, 0, 0, 0, 1, 0],
    [0, 2, 1, 1, 0, 1, 0],
    [0, 3, 1, 1, 0, 5, 0],
    [0, 0, 0, 1, 1, 1, 0]];
}

function level6() {
  resetPosition();
  resetGetting();
  gameState = 6;
  cakeStock = 1;
  resetButtons();
  button6.attribute("src", "images_c/button6Click.png");
  person2.attribute("src", "images_c/person2.png");
  hintPane.attribute("src", "images_c/hintPane6.png");
  level.attribute("src", "images_c/level6.png");
  board = [
    [0, 0, 0, 0, 0, 5, 0],
    [0, 2, 4, 6, 0, 6, 0],
    [0, 3, 1, 1, 0, 1, 0],
    [0, 0, 0, 1, 1, 1, 0]];
}

function level7() {
  resetPosition();
  resetGetting();

  console.log("Current level is level 7");
  gameState = 7;
  resetButtons();
  button7.attribute("src", "images_c/button7Click.png");
  person2.attribute("src", "images_c/person2.png");
  // person2.position(x_b, y_b);
  hintPane.attribute("src", "images_c/hintPane7.png");
  level.attribute("src", "images_c/level7.png");

  //RL: these need to be here so when you change level the person is in the right place(!)
  // x_b = 750;
  // y_b = 430;
  //RL: these need to be here so when you change level we do not have coffe and cakes from the last level

  transferStock = 1;
  board = [
    [0, 0, 0, 0, 0, 5, 0],
    [0, 2, 4, 6, 0, 6, 0],
    [0, 3, 1, 1, 0, 1, 0],
    [0, 0, 0, 1, 1, 1, 0]];
}

function level8() {
  resetPosition();
  resetGetting();
  person2.attribute("src", "images_c/person2.png");
  person2.position(x_b, y_b);
  gameState = 8;
  cakeStock = 1;
  resetButtons();
  button8.attribute("src", "images_c/button8Click.png");
  hintPane.attribute("src", "images_c/hintPane8.png");
  level.attribute("src", "images_c/level8.png");
  //RL: these need to be here so when you change level the person is in the right place(!)
  // x_b = 750;
  // y_b = 430;
  //RL: these need to be here so when you change level we do not have coffe and cakes from the last level
  board = [
    [0, 0, 0, 0, 0, 5, 0],
    [0, 2, 4, 6, 0, 6, 0],
    [0, 3, 1, 1, 0, 1, 0],
    [0, 0, 0, 1, 1, 1, 0]];
}

function resetButtons() {
  character.attribute("src", "images_c/person.png");
  button1.attribute("src", "images_c/button1.png");
  button2.attribute("src", "images_c/button2.png");
  button3.attribute("src", "images_c/button3.png");
  button4.attribute("src", "images_c/button4.png");
  button5.attribute("src", "images_c/button5.png");
  button6.attribute("src", "images_c/button6.png");
  button7.attribute("src", "images_c/button7.png");
  button8.attribute("src", "images_c/button8.png");

  // hint1.attribute("src", "images_c/hint1.png");
  // hint2.attribute("src", "images_c/hint2.png");
  // hint4.attribute("src", "images_c/hint4.png");
  // hint6.attribute("src", "images_c/hint6.png");
  // button9.attribute("src", "images/button9.png");
  // button10.attribute("src", "images/button10.png");
}

function placeButtons() {
  button1 = createImg("images_c/button1.png");
  button1.position(buttonXPos1, 30);
  hint1 = createImg("images_c/hint1.png");
  hint1.position(buttonXPos1,70);

  button2 = createImg("images_c/button2.png");
  buttonXPos2 = buttonXPos1 + 80;
  button2.position(buttonXPos2, 30);
  // hint2 = createImg("images_c/hint2.png");
  // hint2.position(buttonXPos2,70);

  button3 = createImg("images_c/button3.png");
  buttonXPos3 = buttonXPos2 + 80;
  button3.position(buttonXPos3, 30);
  // hint3 = createImg("images_c/hint3.png");
  // hint3.position(buttonXPos3,70);

  button4 = createImg("images_c/button4.png");
  buttonXPos4 = buttonXPos3 + 80;
  button4.position(buttonXPos4, 30);
  hint4 = createImg("images_c/hint4.png");
  hint4.position(buttonXPos4,70);

  button5 = createImg("images_c/button5.png");
  buttonXPos5 = buttonXPos4 + 80;
  button5.position(buttonXPos5, 30);
  // hint5 = createImg("images_c/hint5.png");
  // hint5.position(buttonXPos5,70);

  button6 = createImg("images_c/button6.png");
  buttonXPos6 = buttonXPos5 + 80;
  button6.position(buttonXPos6, 30);
  hint6 = createImg("images_c/hint6.png");
  hint6.position(buttonXPos2,70);

  button7 = createImg("images_c/button7.png");
  buttonXPos7 = buttonXPos6 + 80;
  button7.position(buttonXPos7, 30);
  // hint7 = createImg("images_c/hint7.png");
  // hint7.position(buttonXPos7,70);

  button8 = createImg("images_c/button8.png");
  buttonXPos8 = buttonXPos7 + 80;
  button8.position(buttonXPos8, 30);
  // hint8 = createImg("images_c/hint8.png");
  // hint8.position(buttonXPos8,70);

  // button9 = createImg("images/button9.png");
  // buttonXPos9 = buttonXPos8 + 68;
  // button9.position(buttonXPos9, 30);
  // button10 = createImg("images/button10.png");
  // buttonXPos10 = buttonXPos9 + 68;
  // button10.position(buttonXPos10, 30);
}

function moveright() {
  x = x + 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function moveleft() {
  x = x - 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function moveup() {
  y = y - 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function movedown() {
  y = y + 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function transfer() {
  if(transferBounds()){
    if(transferStock > 0){
      getTransfer++;
    } else{
      alert("There is nothing can be pick up")
    }
  }
  else{
    alert("You can not transfer food here!");
  }

}


function waiter_transfer() {
  if(waiter_transferBounds()){
    if(getMeal > 0){
      transferStock++;
      console.log("You pick up some thing from transfer table", transferStock);
    } else{
      alert("There is no thing can be transfered");
    }
  }
  else{
    alert("You can not transfer food here!");
  }
}


function waiter_moveright() {
  x_b = x_b + 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}


function waiter_moveleft() {
  x_b = x_b - 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function waiter_moveup() {
  y_b = y_b - 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function waiter_movedown() {
  y_b = y_b + 100;
  step++;
  //person.position(x,y); //this gets immediately replaced by the call in 'draw'
}

function pick_up_coffee() {
  if (drinkBounds()){
    getCoffee++;
    console.log("pick up one coffee" + getCoffee);
  }
  else {
    alert("You can not pick up coffee here!");
  }

}

function pick_up_tea() {
  character.attribute("src", "images_c/coffee.png");
  console.log("pick up tea");
}

function pick_up_hot_chocolate() {
  character.attribute("src", "images_c/coffee.png");
  console.log("pick up hot_chocolate");
}

function pick_up_cake() {

  if (cakeBounds()){
      getCake++;
      cakeStock--;
      console.log("pick up one cake", getCake);
  }
  else {
    alert("You can not pick up cake here! ");
  }

  // cake.position(x,y+30);
  // person.attribute("src","images/cake.png");
  // console.log(getCake);
  // console.log('cakeStock:' + cakeStock);
}

function pick_up_sandwich(){
  if (sandwichBounds()){
      getSandwich++;
      console.log(sandwichBounds());
      console.log("Pick up sandwich");
      console.log(getSandwich);
  }
  else {
    alert("You can not pick up sandwich here! ");
  }

  // cake.position(x,y+30);
  // person.attribute("src","images/cake.png");
}

function pick_up_salads(){
  if (saladsBounds()){
      getSalads++;
      console.log(getSalads);
  }
  else {
    alert("You can not pick up salads here! ");
  }
}

function waiter_pick_up_salads(){
  if (waiter_saladsBounds()){
      getSalads++;
      console.log("waiter got salads:",  getSalads);
  }
  else {
    alert("You can not pick up salads here! ");
  }
}



function pick_up_meal(){
  console.log(mealBounds());
  if (mealBounds()){
      getMeal++;
      console.log("I have get the meal" , getMeal)
  }
  else {
    alert("You can not pick_up_meal! ");
  }
}

function waiter_pick_up_meal(){
  if (waiter_mealBounds()){
      getMeal++;
      console.log("pick up one meat", getMeal);
  }
  else {
    alert("You can not pick up meal here! ");
  }
}

function checkCakeStock(){
  if (cakeBounds()){
      return cakeStock;
  }
  else {
    alert("You can not check cake here! ");
  }
}

function checkSaladsStock(){
  if (saladsBounds()){
      return saladsStock;;
  }
  else {
    alert("You can not check salad here! ");
  }
}

function checkSandwichStock(){
  if (cakeBounds()){
      return sandwichStock;
  }
  else {
    alert("You can not check sandwich here! ");
  }
}

function closePop() {
    var screens= document.getElementsByClassName("pop")
    for (let i = screens.length - 1; i >= 0; i--) {
        var screen = screens[i];
        screen.style.display = "none";
    }
}

function showPop1(){
  document.getElementById("hint1Pop").style.display="block";
}

function showPop2(){
  document.getElementById("hint2Pop").style.display="block";
}

function showPop4(){
  document.getElementById("hint4Pop").style.display="block";
}

function showPop6(){
  document.getElementById("hint6Pop").style.display="block";
}

function showPopCongrat(){
  document.getElementById("congratPop").style.display="block";
}

function backToTill(){
  x = 880;
  y = 500;
}

function waiter_backToTill(){
  x_b = 880;
  y_b = 500;
}

function checkTransferStock(){
  if(transferBounds()){
    return transferStock;
  }
  else{
    alert("You can not check transfer stock here!");
  }
}
