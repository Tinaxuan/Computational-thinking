

var myArray = getUsers();
get_currentUser();
var currentUserData;

// var currentUserData =  {'username':'Maggie', 'game_c':1, 'game_w':1, 'game_h':1}


setTimeout(() => {
  //add score property.
  for (var i = 0; i < myArray.length; i++){
    myArray[i].score = myArray[i].game_c + myArray[i].game_w + myArray[i].game_h;
  }
  console.log(myArray);

  jsonSort(myArray,"score", true);
  buildTable(myArray);
  var name_tag = document.getElementById("name_tag");
  name_tag.innerHTML = "Hi, " + currentUserData.name;


  var my_game_c = document.getElementById('my_game_c');
  my_game_c.innerHTML = currentUserData.game_c;

  var my_game_w = document.getElementById('my_game_w');
  my_game_w.innerHTML = currentUserData.game_w;

  var my_game_h = document.getElementById('my_game_h');
  my_game_h.innerHTML =  currentUserData.game_h;

  var my_score = document.getElementById('score');
  my_score.innerHTML = "My Scores: " + (currentUserData.game_c + currentUserData.game_w + currentUserData.game_h);

},500)



//sore object by score(reverse).
function jsonSort(array, field, reverse) {
    if (array.length < 2 || !field || typeof array[0] !== "object") return array;
    if (typeof array[0][field] === "number") {
        array.sort(function (x, y) { return x[field] - y[field] });
    }
    if (typeof array[0][field] === "string") {
        array.sort(function (x, y) { return x[field].localeCompare(y[field]) });
    }
    if (reverse) {
        array.reverse();
    }
    return array;
}


//build table to html.
function buildTable(data){
  var table = document.getElementById('myTable')

  for (var i = 0; i < data.length; i++){
    var row = `<tr>
            <td>${data[i].username}</td>
            <td>${data[i].game_c}</td>
            <td>${data[i].game_w}</td>
            <td>${data[i].game_h}</td>
            <td>${data[i].score}</td>
          </tr>`
    table.innerHTML += row
  }
}

//array of current user.
// var newArr = myArray.filter(function(p){
//   return p.name === "mingxuan";//这里换成当前用户名
// });



var btn = document.getElementById('open_btn');
var div = document.getElementById('background');
var close = document.getElementById('close-button');

// btn.onclick = function show() {
// 	div.style.display = "block";
// }

close.onclick = function close() {
	div.style.display = "none";
}

window.onclick = function close(e) {
	if (e.target == div) {
		div.style.display = "none";
	}
}
