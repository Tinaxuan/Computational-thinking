console.log("ClientUI.js")

let currentUser;

window.onload =  function() {
    document.getElementById("login").onclick = () => login();
    document.getElementById("register").onclick = () => toRegisteringHomepage();
    document.getElementById("signup").onclick = () => getNewUserinfo();
    document.getElementById("logout").onclick = () => logout();
    // document.getElementById("index").onclick = () => index();

    get_currentUser();
    setTimeout(() => {
        console.log("isloggedin", isLogged);
        if(isLogged) {
            document.getElementById("log_page").innerHTML="User Page";
        }
    },300) 
  }

let login = async function(){
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    // check whether the password is equal

    let hashpassword = await hashingpassword(username, password)
    if (hashpassword == "successful"){
        alert("Login Successful")
        currentUser = username

        toUserHomepage()
    } else{
        alert("Please check your username")
    }
}

const logout = function() {
    logout_game();
    currentUser = ""
    window.location.href = "/home.html";
}

//Update by Mengying
let showLogout = function(){
  document.getElementById("log_page").style.display = "none";
  document.getElementById("logout_button").style.display = "block";
  document.getElementById("leaderBoard").style.display = "block";
}

let toUserHomepage = function(){
    document.getElementById("log_main").style.display = "none";
    document.getElementById("userHomepage").style.display = "block";
    document.getElementById("currentUser").innerHTML = currentUser;
}
let toRegisteringHomepage = async function(){
    document.getElementById("log_main").style.display = "none";
    document.getElementById("registerHomepage").style.display = "block";

}
let getNewUserinfo = async function(){
    let newUserName = document.getElementById("newusername").value;
    let newPassWord = document.getElementById("newpassword").value;
    let confirmNewUser = await addUser(newUserName, newPassWord)
    if(confirmNewUser == "User added"){
        alert(confirmNewUser)
        currentUser = newUserName
        document.getElementById("log_main").style.display = "none";
        document.getElementById("registerHomepage").style.display = "none"
        
    }else{
        alert(confirmNewUser)
    }
}


let open_log = function() {
    if (isLogged) {
        toUserHomepage();

    } else {
        var screen = document.getElementById("log_main");
        screen.style.display = "block";

    }

}

let back_login = function(){
    document.getElementById("registerHomepage").style.display = "none";
    document.getElementById("log_main").style.display = "block";
}

let getAlldata = function() {
    getUsers();
}

let index = function() {

}
