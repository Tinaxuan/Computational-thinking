console.log("client-side.js")
var isLogged = false;

const hashingpassword = async function(username, password) {
    let msgReturn
    console.log("zhe")
    await fetch(`checkinghash/${username}`, {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password:password})
        })
        .then(res => res.json())
        .then(dta => {
            console.log(dta.msg)
            msgReturn = dta.msg
        })
        .catch(err => console.log(err))
    return msgReturn
}

// get all users
const getUsers = function(){
    let array;
    fetch("/users")
        .then(res => res.json())
        .then(users =>{
            myArray = users;
           // console.log("Array", myArray);
        })
        .catch(err =>{
            console.log("Could not fetch users",err)
        })
   return array;
}


const addUser = async function(username, password) {
    let msg
    await fetch("/users/addUser", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username, password: password })
        })
        .then(res => res.json())
        .then(dta => {
            console.log(dta);
            msg = dta.msg;
        })
        .catch(err => console.log(err))
    return msg
}

const updateGame_c = async function(username, score) {
    let msg;
    await fetch("/scores/gamec", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({username: username, score: score })
        })
        .then(res => res.json())
        .then(dta => {
            console.log(dta)
            msg = dta.msg;
        })
        .catch(err => console.log(err))
    return msg
}
const updateGame_w = async function(username, score) {
    let msg;
    await fetch("/scores/gamew", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({username: username, score: score })
        })
        .then(res => res.json())
        .then(dta => {
            console.log(dta)
            msg = dta.msg;
        })
        .catch(err => console.log(err))
    return msg
}

const updateGame_h = async function(username, score) {
    let msg;
    await fetch("/scores/gameh", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({username: username, score: score })
        })
        .then(res => res.json())
        .then(dta => {
            console.log(dta)
            msg = dta.msg;
        })
        .catch(err => console.log(err))
    return msg
}

const get_currentUser = function() {
    fetch('/user/current')
    .then(res => res.json())
    .then(jsn => {
        if (jsn.msg === "Successful") {
            isLogged = true;
            currentUser = jsn.session.user.name;
            currentUserData = jsn.session.user;
            console.log("isloggedin", isLogged);
            console.log("current user", currentUser)
        } else {
            console.log(jsn.msg)        }
    })
    .catch(err => console.log(err));
}

const logout_game = function() { 
    let msgReturn
    fetch('/logout')
        .then(res => res.json())
        .then(dta => {
            console.log(dta.msg)
            msgReturn = dta.msg
        })
        .catch(err => console.log(err))
return msgReturn
}



